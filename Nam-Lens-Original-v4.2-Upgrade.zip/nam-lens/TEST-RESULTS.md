# Checks for Nam Lens 4.2

Test environment: Linux, Node.js 24.19.0, Chromium 153 with Playwright, Python 3.12. Tests used isolated temporary workspaces; no personal workspace data or live provider accounts were used.

| Check | Result |
| --- | --- |
| Public home displays account buttons before forms | Passed |
| Public User guide opens without an account | Passed |
| First local registration creates the owner | Passed |
| Password hashes hidden from workspace responses | Passed |
| Subsequent registrations wait for approval and cannot self-assign admin access | Passed |
| Login, logout, wrong-password rejection and enforced role permissions | Passed |
| Owner identity, credentials and saved story after server restart | Passed |
| Stepped story form: Next, Back, retained values, validation and actual save | Passed in browser |
| Personal language draft saves and restores on reload | Passed in browser and database checks |
| No horizontal overflow in tested home/workspace/studio layouts | Passed at 320, 390, 768 and 1440 pixels |
| Public guide, registration, menu, story and language workflow | No JavaScript errors in tested browser paths |
| Reduced-motion display | Checked in browser screenshots |
| Speech capability discovery, timed transcript response and unsupported-language handling | Passed against a controlled test service |
| Optional worker authentication and media decoding | Passed |
| Real English speech-to-text with timestamps | Passed on an English speech fixture |
| Non-speech input rejected for the experimental Oshiwambo path | Passed |
| Experimental Oshiwambo model loads and executes inference | Passed; speech input was English, so this does **not** measure Oshiwambo accuracy |
| PDF, spreadsheet, Word and full backup download generation | Passed |
| Original 4.1 account, story and original attachment preserved by copy upgrade | Passed |
| Original 4.1 backup restores account, story, attachment and correct owner identity | Passed |
| Original folder retained by upgrade helper | Passed |
| Prebuilt main app rebuild | Passed |

Optional reproducible core checks: with the speech engine stopped, run `node tools/test-core.mjs`. This uses temporary data and a controlled speech fixture; it does not evaluate real language accuracy.

## Practical limits

Actual Windows double-click, macOS, Android/iOS hardware, Firefox/Safari, microphone permission prompts, Docker deployment and public hosting have not been tested in this environment. Viewport checks establish responsive layout, not universal compatibility with every device brand or operating system. The main app remains local until hosted; another device cannot open this computer's localhost address.

Existing feed/social/provider integrations and broadcast scheduling have been retained. Real source URLs, provider keys, permissions, delivery destinations and station access still determine whether external collection and delivery succeed. They were not supplied for live external testing here.

The optional AI engine is a separate installation with model downloads. Its English fixture and model execution checks are not independent indigenous-language validation. Real Oshiwambo recordings, dialect variation, speaker diversity, background noise and news vocabulary require evaluation by fluent speakers. No ready AI engine is bundled for every listed language.

The speech dependency's default telemetry caused an automatic test rejection. The worker and launcher now disable ONNX Runtime telemetry before initialization and disable Hugging Face telemetry. The affected speech checks then completed successfully with telemetry disabled.
