# Nam Lens 4.2

Update of the original local media desk. Start with READ-ME-FIRST.txt, then double-click START-NAM-LENS.cmd. The source and prebuilt application are included.

Use the public User guide in the home-page menu. Hosting is a separate later step; HOSTING.md describes the server requirements.
