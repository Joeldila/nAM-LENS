# Private speech engine connection

The built-in worker stays on localhost (port 8876 for the local launcher), or on a private Docker network. Do not publish the worker directly.

Nam Lens sends authenticated requests to `/health` and `/transcribe` on the configured base address. The optional local launcher generates a private connection key in the data directory and the app reads it automatically. Administrator-entered connection keys are stored encrypted.

A compatible service returns a health object with `languages`, `experimental`, `provider` and `loaded`. The shipped worker advertises `en`, `af`, `de` and, when enabled, the custom family tag `oshiwambo`. This custom tag is intentionally not `os`, which is the language code for Ossetian. `ndo`, `kua`, `her`, `naq`, `kwn`, `loz` and `tsn` are the separate language tags supported by the application contract when a suitable engine advertises them. The shipped worker does not advertise these indigenous language tags as working AI.

Transcription accepts a multipart `file` and `language` and returns `text`, optional `segments` containing start/end seconds and text, plus optional language metadata. Empty transcripts are treated as no speech. The application always requires human checking. No translation into English is silently substituted for an original-language transcript.

The model card and limits are linked in RELEASE-NOTES.md. Dependencies and weights install separately; their licenses remain applicable. Telemetry opt-outs are set before ONNX Runtime or model libraries initialize.
