"""Private speech engine. Draft transcripts must be checked by a fluent speaker."""
import os
os.environ["ORT_DISABLE_TELEMETRY"]="1"
os.environ["HF_HUB_DISABLE_TELEMETRY"]="1"
import tempfile, threading, hmac
import numpy as np
import av
import onnxruntime as ort
ort.disable_telemetry_events()
from fastapi import FastAPI, UploadFile, File, Form, Header, HTTPException
from starlette.concurrency import run_in_threadpool
from faster_whisper import WhisperModel

app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
models = {}
lock = threading.Lock()
OSH_MODEL = "jpandeinge/whisper-tiny-oshiwambo-speech"

def authenticate(header):
    token = os.environ.get("NAMLENS_SPEECH_TOKEN", "")
    if not token or not hmac.compare_digest(header or "", "Bearer " + token):
        raise HTTPException(401, "Authentication required")

def oshiwambo_enabled():
    return os.environ.get("NAMLENS_OSHIWAMBO_EXPERIMENT", "0") == "1"

@app.get("/health")
def health(authorization: str = Header(default="")):
    authenticate(authorization)
    return {"ok": True, "loaded": bool(models), "provider": "Nam Lens private speech engine", "languages": ["en", "af", "de"] + (["oshiwambo"] if oshiwambo_enabled() else []), "experimental": ["oshiwambo"] if oshiwambo_enabled() else []}

def decode_audio(name):
    parts = []
    samples = 0
    with av.open(name) as container:
        resampler = av.AudioResampler(format="s16", layout="mono", rate=16000)
        for frame in container.decode(audio=0):
            for f in resampler.resample(frame):
                a=f.to_ndarray().flatten().astype(np.float32)/32768.0
                samples += len(a)
                if samples > 16000*600:
                    raise ValueError("Use clips of no more than 10 minutes")
                parts.append(a)
        for f in resampler.resample(None):
            parts.append(f.to_ndarray().flatten().astype(np.float32)/32768.0)
    if not parts: raise ValueError("No audio found")
    return np.concatenate(parts)

def recognise(name, language):
    with lock:
        if language == "oshiwambo":
            if not oshiwambo_enabled(): raise ValueError("Oshiwambo experiment is not enabled")
            if "oshiwambo" not in models:
                from transformers import pipeline
                models["oshiwambo"] = pipeline("automatic-speech-recognition", model=OSH_MODEL, device=-1, chunk_length_s=25)
            pcm=decode_audio(name)
            from faster_whisper.vad import get_speech_timestamps
            if not get_speech_timestamps(pcm):
                return {"text":"","segments":[],"language":"Oshiwambo","experimental":True,"reviewed":False}
            result = models["oshiwambo"]({"raw":pcm, "sampling_rate":16000}, return_timestamps=True)
            segments=[]
            for chunk in result.get("chunks", []):
                start,end=chunk.get("timestamp", (None,None))
                if start is not None and end is not None:
                    segments.append({"start":float(start),"end":float(end),"text":chunk.get("text","").strip()})
            return {"text":result.get("text","").strip()[:60000],"segments":segments,"language":"Oshiwambo","experimental":True,"reviewed":False}
        if "whisper" not in models:
            models["whisper"] = WhisperModel(os.environ.get("WHISPER_MODEL", "tiny"), device="cpu", compute_type="int8", cpu_threads=2)
        # Decode first to apply the same duration limit to every language.
        pcm=decode_audio(name)
        parts, info = models["whisper"].transcribe(pcm, language=language, vad_filter=True, beam_size=3)
        segments=[{"start":float(x.start),"end":float(x.end),"text":x.text.strip()} for x in parts]
        return {"text":" ".join(x["text"] for x in segments)[:60000],"segments":segments,"language":info.language,"reviewed":False}

@app.post("/transcribe")
async def transcribe(file: UploadFile = File(...), language: str = Form(default="en"), authorization: str = Header(default="")):
    authenticate(authorization)
    if language not in ["en", "af", "de"] + (["oshiwambo"] if oshiwambo_enabled() else []):
        raise HTTPException(400, "No speech model is connected for this language")
    name = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".media") as output:
            name = output.name
            size = 0
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > 40 * 1024 * 1024: raise HTTPException(413, "Recording exceeds 40 MB")
                output.write(chunk)
        return await run_in_threadpool(recognise, name, language)
    except HTTPException: raise
    except Exception as e:
        print("Speech processing failed:", type(e).__name__, str(e), flush=True)
        raise HTTPException(502, "Speech processing failed. Try a short, clear recording or enter its transcript.")
    finally:
        if name and os.path.exists(name): os.unlink(name)
