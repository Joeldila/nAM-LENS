import {spawn} from 'node:child_process';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const folder=path.dirname(fileURLToPath(import.meta.url));process.chdir(folder);
const [major,minor]=process.versions.node.split('.').map(Number);
if(major<22||major===22&&minor<13){console.error('Please install Node.js 22.13 or newer. Then double-click START-NAMIBIA.cmd again.');process.exit(1)}
if(!fs.existsSync('server.mjs')||!fs.existsSync('public/index.html')){console.error('The app files are missing. Extract the full ZIP first, then run START-NAMIBIA.cmd from the extracted folder.');process.exit(1)}
const taskDataDir=path.resolve(process.env.NMO_DATA_DIR||'data');fs.mkdirSync(taskDataDir,{recursive:true});const log=fs.createWriteStream(path.join(taskDataDir,'startup.log'),{flags:'a'});log.write('\nStarted '+new Date().toISOString()+'; Node '+process.versions.node+'\n');
const child=spawn(process.execPath,['--no-warnings','server.mjs'],{cwd:folder,stdio:['inherit','pipe','pipe']});for(const [stream,target] of [[child.stdout,process.stdout],[child.stderr,process.stderr]])stream.on('data',chunk=>{target.write(chunk);log.write(chunk)});
child.on('error',e=>{console.error('Could not start: '+e.message);log.end(e.stack);process.exitCode=1});child.on('exit',(code)=>{log.end();if(code){console.error('\nThe app stopped. The details are in data/startup.log.');process.exitCode=code}});process.on('SIGINT',()=>child.kill('SIGINT'));process.on('SIGTERM',()=>child.kill('SIGTERM'));
