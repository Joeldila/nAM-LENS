#!/bin/sh
set -eu
data_path="${NMO_DATA_DIR:-/data}"
mkdir -p "$data_path"
if [ "$(id -u)" = "0" ]; then
  # A newly mounted persistent disk may be root-owned.
  if [ "$(stat -c %u "$data_path")" != "1000" ]; then
    chown -R node:node "$data_path"
  fi
  exec gosu node "$@"
fi
exec "$@"
