import {createInterface} from 'node:readline/promises';
import fs from 'node:fs';
import {randomBytes} from 'node:crypto';
const input=createInterface({input:process.stdin,output:process.stdout});
try{
 if(fs.existsSync('.env'))throw Error('.env already exists. Edit it to change hosting settings; your existing configuration was preserved.');
 const domain=(await input.question('Your domain (for example namlens.example.com): ')).trim();
 if(!/^(?:[a-z0-9-]+\.)+[a-z]{2,}$/i.test(domain))throw Error('Enter a domain name, without https:// or a path.');
 const email=(await input.question('Owner email: ')).trim();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('A valid email is required.');
 const password=randomBytes(20).toString('base64url'),token=randomBytes(32).toString('hex');
 fs.writeFileSync('.env',`NAMLENS_DOMAIN=${domain}\nNAMLENS_PUBLIC_URL=https://${domain}\nNAMLENS_ADMIN_EMAIL=${email}\nNAMLENS_ADMIN_PASSWORD=${password}\nNAMLENS_SPEECH_TOKEN=${token}\nNAMLENS_RECORDING_MB=500\n`,{mode:0o600});
 console.log('Hosting configuration created. Your initial owner password is in .env. Keep that file private.');
 console.log('Start with: docker compose up -d --build');
}catch(e){console.error(e.message);process.exitCode=1;}finally{input.close();}
