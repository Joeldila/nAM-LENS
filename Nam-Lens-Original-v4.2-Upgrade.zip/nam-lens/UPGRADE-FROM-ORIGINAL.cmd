@echo off
cd /d "%~dp0"
node tools\upgrade.mjs
pause
