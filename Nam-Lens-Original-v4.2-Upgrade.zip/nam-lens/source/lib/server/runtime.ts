import fs from "node:fs";
import path from "node:path";
import { dataDir, db, getRecord, putRecord } from "./store";
export const hosted = process.env.NAMLENS_HOSTED === "1";
export const origin = hosted
  ? new URL(
      process.env.NAMLENS_PUBLIC_URL ||
        process.env.RENDER_EXTERNAL_URL ||
        "https://not-configured.invalid",
    ).origin
  : "";
export function validateRuntime() {
  if (!hosted) return;
  if (
    !(process.env.NAMLENS_PUBLIC_URL || process.env.RENDER_EXTERNAL_URL) ||
    (!origin.startsWith("https://") && process.env.NAMLENS_TEST_HTTP !== "1")
  )
    throw Error("Hosted mode requires NAMLENS_PUBLIC_URL with HTTPS.");
  if (
    !process.env.NAMLENS_ADMIN_PASSWORD ||
    process.env.NAMLENS_ADMIN_PASSWORD.length < 12
  )
    throw Error(
      "Hosted mode requires an initial NAMLENS_ADMIN_PASSWORD of at least 12 characters.",
    );
}
export async function automaticBackup(force = false) {
  const last = await getRecord("auto-backup");
  if (!force && last?.date && Date.now() - Date.parse(last.date) < 86400000)
    return;
  const base = path.join(dataDir, "backups");
  fs.mkdirSync(base, { recursive: true });
  const date = new Date().toISOString(),
    dest = path.join(base, date.replace(/[:.]/g, "-"));
  fs.mkdirSync(dest);
  try {
    db.exec(
      "VACUUM INTO '" +
        path.join(dest, "observatory.sqlite").replace(/'/g, "''") +
        "'",
    );
    for (const name of ["evidence", "workspace.key"]) {
      const source = path.join(dataDir, name);
      if (fs.existsSync(source))
        fs.cpSync(source, path.join(dest, name), { recursive: true });
    }
    fs.writeFileSync(
      path.join(dest, "manifest.json"),
      JSON.stringify({
        app: "Nam Lens",
        date,
        restore:
          "Stop the app, then copy this folder’s database, workspace.key and evidence into its data folder.",
      }),
    );
    await putRecord({
      id: "auto-backup",
      kind: "settings",
      date,
      status: "Saved",
      folder: path.basename(dest),
    });
    const folders = fs
      .readdirSync(base)
      .filter((x) => fs.statSync(path.join(base, x)).isDirectory())
      .sort()
      .reverse();
    for (const old of folders.slice(3))
      fs.rmSync(path.join(base, old), { recursive: true, force: true });
    return { ok: true, date };
  } catch (e: any) {
    fs.rmSync(dest, { recursive: true, force: true });
    await putRecord({
      id: "auto-backup",
      kind: "settings",
      date,
      status: "Failed",
      error: e.message,
    });
    throw e;
  }
}
