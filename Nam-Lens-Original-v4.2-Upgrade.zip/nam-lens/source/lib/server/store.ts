import * as sqlite from "node:sqlite";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
export const dataDir = path.resolve(
  process.env.NMO_DATA_DIR ||
    path.join(path.dirname(fileURLToPath(import.meta.url)), "data"),
);
fs.mkdirSync(dataDir, { recursive: true });
const Database = (sqlite as any).Database || (sqlite as any).DatabaseSync;
export let db = new Database(path.join(dataDir, "observatory.sqlite"));
export function openDB() {
  db = new Database(path.join(dataDir, "observatory.sqlite"));
  configure();
}
function configure() {
  db.exec(
    "PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS records (id TEXT PRIMARY KEY,kind TEXT NOT NULL,data TEXT NOT NULL,updatedAt TEXT NOT NULL); CREATE INDEX IF NOT EXISTS records_kind ON records(kind)",
  );
}
configure();
export async function allRecords() {
  return db
    .prepare("SELECT id,kind,data FROM records ORDER BY updatedAt DESC")
    .all()
    .map((r: any) => ({ ...JSON.parse(r.data), id: r.id, kind: r.kind }));
}
export async function getRecord(id: string) {
  const r = db.prepare("SELECT id,kind,data FROM records WHERE id=?").get(id);
  return r ? { ...JSON.parse(r.data), id: r.id, kind: r.kind } : null;
}
export async function putRecord(item: any) {
  const { id, kind, ...data } = item;
  db.prepare(
    "INSERT INTO records VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET kind=excluded.kind,data=excluded.data,updatedAt=excluded.updatedAt",
  ).run(id, kind, JSON.stringify(data), new Date().toISOString());
  return item;
}
export async function insertRecord(item: any) {
  const { id, kind, ...data } = item;
  const r = db
    .prepare("INSERT OR IGNORE INTO records VALUES (?,?,?,?)")
    .run(id, kind, JSON.stringify(data), new Date().toISOString());
  return r.changes ? [item] : [];
}
export async function deleteRecord(id: string) {
  db.prepare("DELETE FROM records WHERE id=?").run(id);
}
