import { queueAnalysis } from "./automatic-analysis";
import { publicURL, publicFetch, limitedBytes } from "./network";
export { publicURL } from "./network";
import { XMLParser } from "fast-xml-parser";
import { getRecord, putRecord, allRecords, insertRecord } from "./store";
import { analyse } from "@/lib/analysis";
import { enrich } from "@/lib/intelligence";
import { socialSearch } from "./providers";
const plain = (v: any) =>
  String(typeof v === "object" ? v?.["#text"] || "" : v || "")
    .replace(/<[^>]*>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
export function parseFeed(xml: string) {
  const parsed = new XMLParser({
    ignoreAttributes: false,
    attributeNamePrefix: "@_",
    processEntities: true,
  }).parse(xml);
  const feed =
    parsed.rss?.channel?.item || parsed.feed?.entry || parsed["rdf:RDF"]?.item;
  if (!feed) return [];
  return (Array.isArray(feed) ? feed : [feed])
    .slice(0, 50)
    .map((p: any) => {
      const links = Array.isArray(p.link) ? p.link : [p.link];
      const link = links.find(
        (l: any) =>
          typeof l === "string" || !l?.["@_rel"] || l["@_rel"] === "alternate",
      );
      return {
        title: plain(p.title),
        body: plain(
          p["content:encoded"] ||
            p.description ||
            p.content ||
            p.summary ||
            p.title,
        ),
        url: typeof link === "string" ? link : link?.["@_href"] || "",
        date:
          p.pubDate ||
          p.published ||
          p.updated ||
          p["dc:date"] ||
          new Date().toISOString(),
      };
    })
    .filter((p: any) => p.title);
}
async function storeStories(items: any[], sourceId: string, source: any) {
  const entities = (await allRecords()).filter((r) => r.kind === "entity");
  let count = 0;
  for (const p of items) {
    if (!p.body?.trim()) continue;
    const seed = sourceId + "|" + (p.externalId || p.url || p.title);
    const hash = Array.from(
      new Uint8Array(
        await crypto.subtle.digest("SHA-256", new TextEncoder().encode(seed)),
      ),
    )
      .map((x) => x.toString(16).padStart(2, "0"))
      .join("");
    const date = !isNaN(Date.parse(p.date))
      ? new Date(p.date).toISOString()
      : new Date().toISOString();
    const language = p.language || source.language || "English";
    const record = enrich(
      {
        ...p,
        id: "collected-" + hash,
        kind: "story",
        body: p.body.slice(0, 60000),
        source: p.source || source.name,
        channel: p.channel || source.channel,
        language,
        region: source.region || "National",
        date,
        url: /^https?:\/\//.test(p.url) ? p.url : "",
        ...analyse(p.title + " " + p.body, language),
        sample: false,
        saved: false,
        verification: "Not assessed",
        status: "Open",
        approval: "Draft",
        notes: "",
        sourceId,
      },
      entities,
    );
    const created = await insertRecord(record);
    if (created.length) {
      count++;
      await queueAnalysis(record);
    }
  }
  return count;
}
export async function collectSource(id: string) {
  const source = await getRecord(id);
  if (!source || source.kind !== "source") throw Error("Source not found");
  if (!source.enabled) throw Error("Source is paused");
  const u = publicURL(source.url);
  let failure = "";
  let attempts = 0;
  for (attempts = 1; attempts <= 3; attempts++) {
    try {
      const res = await publicFetch(u);
      if (!res.ok) throw Error("Source returned HTTP " + res.status);
      const xml = (await limitedBytes(res, 2000000)).toString("utf8");
      if (xml.length > 2000000) throw Error("Feed exceeds 2 MB");
      if (!/<rss|<feed|<rdf:RDF/i.test(xml))
        throw Error("This URL is not a supported RSS/Atom feed");
      const items = parseFeed(xml);
      const count = await storeStories(items, id, source);
      await putRecord({
        ...source,
        health: "Connected",
        lastSync: new Date().toISOString(),
        lastError: "",
        lastAttempts: attempts,
        lastCount: count,
        nextRetry: null,
      });
      return { source: source.name, count, attempts };
    } catch (e) {
      failure = (e as Error).message;
      if (/not a supported|exceeds|HTTP 4/.test(failure)) break;
      await new Promise((r) => setTimeout(r, attempts * 150));
    }
  }
  await putRecord({
    ...source,
    health: "Needs attention",
    lastCheck: new Date().toISOString(),
    lastError: failure,
    lastAttempts: Math.min(attempts, 3),
    nextRetry: new Date(Date.now() + 3600000).toISOString(),
  });
  throw Error(source.name + ": " + failure);
}
export async function collectSocial(id: string) {
  const cfg = await getRecord("integration-" + id);
  if (!cfg?.enabled) throw Error("Enable this integration first");
  try {
    const items = await socialSearch(id, cfg);
    const count = await storeStories(items, "social-" + id, {
      name: id,
      language: "Other",
      channel: "Social",
      region: "National",
    });
    await putRecord({
      ...cfg,
      health: "Connected",
      lastTest: new Date().toISOString(),
      lastError: "",
      lastCount: count,
    });
    return { source: id, count };
  } catch (e) {
    await putRecord({
      ...cfg,
      health: "Needs attention",
      lastTest: new Date().toISOString(),
      lastError: (e as Error).message,
    });
    throw e;
  }
}
