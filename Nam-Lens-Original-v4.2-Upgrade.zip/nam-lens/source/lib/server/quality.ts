import { getRecord, putRecord, allRecords } from "./store";
import { sentimentModel } from "./providers";
export async function connectedAnalysis(text: string, language: string) {
  if (typeof text !== "string" || !text.trim() || text.length > 60000)
    throw Error("Provide up to 60,000 characters of text.");
  const languages = (process.env.NAMLENS_ANALYSIS_LANGUAGES || "")
    .split(",")
    .map((x) => x.trim());
  if (!process.env.NAMLENS_ANALYSIS_URL || !languages.includes(language))
    return sentimentModel(text, language);
  const r = await fetch(process.env.NAMLENS_ANALYSIS_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + (process.env.NAMLENS_ANALYSIS_TOKEN || ""),
    },
    body: JSON.stringify({ text, language }),
    signal: AbortSignal.timeout(30000),
  });
  if (!r.ok) throw Error("Language service returned HTTP " + r.status);
  const j: any = await r.json();
  if (
    !["Positive", "Negative", "Neutral", "Unclassified"].includes(j.sentiment)
  )
    throw Error("Language service returned an invalid sentiment.");
  return {
    sentiment: j.sentiment,
    confidence:
      typeof j.confidence === "number" && j.confidence >= 0 && j.confidence <= 1
        ? j.confidence
        : null,
    analysisMethod: "Configured language service",
    analysisReason:
      "Experimental model suggestion. Check the language benchmark and review the original text.",
    reviewed: false,
  };
}
export async function addBenchmark(d: any) {
  if (!Array.isArray(d.items) || d.items.length > 100)
    throw Error("Import up to 100 labelled examples.");
  for (const row of d.items) {
    if (
      typeof row.text !== "string" ||
      !row.text.trim() ||
      row.text.length > 5000 ||
      typeof row.language !== "string" ||
      !["Positive", "Negative", "Neutral"].includes(row.sentiment)
    )
      throw Error(
        "Each example needs text, language and a reference sentiment.",
      );
  }
  for (const row of d.items)
    await putRecord({
      id: "benchmark-" + crypto.randomUUID(),
      kind: "benchmark",
      text: row.text,
      language: row.language,
      sentiment: row.sentiment,
      date: new Date().toISOString(),
    });
  return { ok: true, count: d.items.length };
}
export async function evaluateBenchmark(language: string) {
  const examples = (await allRecords())
    .filter((x) => x.kind === "benchmark" && x.language === language)
    .slice(0, 30);
  if (!examples.length)
    throw Error("Import independently labelled examples first.");
  let correct = 0;
  const confusion: Record<string, Record<string, number>> = {};
  const errors: any[] = [];
  let evaluated = 0;
  for (const item of examples) {
    try {
      const result = await connectedAnalysis(item.text, language);
      evaluated++;
      if (result.sentiment === item.sentiment) correct++;
      (confusion[item.sentiment] ??= {})[result.sentiment] =
        ((confusion[item.sentiment] || {})[result.sentiment] || 0) + 1;
    } catch (e: any) {
      errors.push({ id: item.id, error: e.message });
    }
  }
  const out = {
    id: "quality-" + language,
    kind: "quality",
    language,
    count: examples.length,
    evaluated,
    correct,
    accuracy: evaluated ? correct / evaluated : null,
    classes: [...new Set(examples.map((x) => x.sentiment))],
    confusion,
    errors,
    date: new Date().toISOString(),
    status: errors.length
      ? "Connection failures"
      : examples.length < 30
        ? "Small benchmark - more data needed"
        : "Benchmark measured - human acceptance required",
  };
  await putRecord(out);
  return out;
}
