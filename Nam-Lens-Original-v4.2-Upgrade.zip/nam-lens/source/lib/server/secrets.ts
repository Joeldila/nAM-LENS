import { randomBytes, createCipheriv, createDecipheriv } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { dataDir, getRecord, putRecord } from "./store";
function key() {
  const p = path.join(dataDir, "workspace.key");
  if (!fs.existsSync(p))
    fs.writeFileSync(p, randomBytes(32), { mode: 0o600, flag: "wx" });
  const b = fs.readFileSync(p);
  if (b.length !== 32)
    throw Error("Workspace key is invalid. Restore your backup.");
  return b;
}
export async function saveSecret(id: string, value: string) {
  const iv = randomBytes(12);
  const c = createCipheriv("aes-256-gcm", key(), iv);
  const encrypted = Buffer.concat([c.update(value, "utf8"), c.final()]);
  await putRecord({
    id: "secret-" + id,
    kind: "secret",
    iv: iv.toString("hex"),
    tag: c.getAuthTag().toString("hex"),
    value: encrypted.toString("hex"),
  });
}
export async function readSecret(id: string) {
  const r = await getRecord("secret-" + id);
  if (!r) return "";
  const c = createDecipheriv("aes-256-gcm", key(), Buffer.from(r.iv, "hex"));
  c.setAuthTag(Buffer.from(r.tag, "hex"));
  return Buffer.concat([
    c.update(Buffer.from(r.value, "hex")),
    c.final(),
  ]).toString("utf8");
}
