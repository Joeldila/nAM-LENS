import { queueAnalysis } from "./automatic-analysis";
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { randomUUID } from "node:crypto";
import {
  dataDir,
  allRecords,
  getRecord,
  putRecord,
  deleteRecord,
  insertRecord,
} from "./store";
import { publicURL, publicFetch, limitedBytes } from "./network";
import { enrich } from "@/lib/intelligence";
import { analyse } from "@/lib/analysis";
import { transcribeBytes } from "./transcription";
export const captureRunning = new Map<string, { child: any; relay: any }>();
const clips = path.join(dataDir, "evidence");
export function ffmpegAvailable() {
  return (
    spawnSync("ffmpeg", ["-version"], { stdio: "ignore", timeout: 3000 })
      .status === 0
  );
}
export async function saveBroadcast(a: any, d: any) {
  if (d.action === "delete") {
    if (captureRunning.has(d.id))
      throw Error(
        "Pause the stream and wait for the current clip before deleting.",
      );
    await deleteRecord(d.id);
    return { ok: true };
  }
  if (
    typeof d.name !== "string" ||
    !d.name.trim() ||
    d.name.length > 120 ||
    !["Radio", "Television"].includes(d.channel)
  )
    throw Error("Station name and channel are required.");
  publicURL(d.url);
  const seconds = Number(d.seconds || 120),
    retentionDays = Number(d.retentionDays || 3);
  if (
    ![30, 60, 120, 300, 600].includes(seconds) ||
    !Number.isInteger(retentionDays) ||
    retentionDays < 1 ||
    retentionDays > 30
  )
    throw Error("Choose a supported clip length and 1–30 retention days.");
  const old = d.id ? await getRecord(d.id) : null;
  if (old && old.kind !== "broadcast") throw Error("Invalid stream ID.");
  const id = old?.id || "broadcast-" + randomUUID();
  await putRecord({
    ...old,
    id,
    kind: "broadcast",
    name: d.name.trim(),
    url: d.url,
    channel: d.channel,
    language: d.language || "English",
    region: d.region || "National",
    programme: String(d.programme || "").slice(0, 200),
    presenter: String(d.presenter || "").slice(0, 200),
    seconds,
    retentionDays,
    enabled: Boolean(d.enabled),
    transcribe: Boolean(d.transcribe),
    updatedBy: a.name,
    health: d.enabled ? "Waiting for capture" : "Paused",
  });
  if (!d.enabled) captureRunning.get(id)?.child.kill("SIGTERM");
  return { ok: true, id };
}
export function rewritePlaylist(text: string, base: string, relayURL: string) {
  const link = (s: string) => {
    const u = publicURL(new URL(s, base).href);
    return relayURL + "?url=" + encodeURIComponent(u.href);
  };
  return text
    .split(/\r?\n/)
    .map((line) =>
      line.startsWith("#")
        ? line.replace(/URI="([^"]+)"/g, (_, u) => 'URI="' + link(u) + '"')
        : line.trim()
          ? link(line.trim())
          : line,
    )
    .join("\n");
}
async function capture(item: any) {
  if (captureRunning.has(item.id)) return;
  if (!ffmpegAvailable()) {
    await putRecord({
      ...item,
      health: "Needs attention",
      lastError:
        "FFmpeg is not installed. It is included in the hosting Docker image.",
    });
    return;
  }
  const all = await allRecords(),
    size = all
      .filter((x) => x.kind === "evidence")
      .reduce((s, x) => s + (Number(x.size) || 0), 0),
    budget = Number(process.env.NAMLENS_RECORDING_MB || 500) * 1048576;
  if (size > budget) {
    await putRecord({
      ...item,
      health: "Storage limit reached",
      lastError: "Remove or expire recordings before capture resumes.",
    });
    return;
  }
  fs.mkdirSync(clips, { recursive: true });
  const key = randomUUID(),
    file = path.join(clips, key),
    nonce = randomUUID();
  const relay = http.createServer(async (req, res) => {
    try {
      const u = new URL(req.url || "", "http://127.0.0.1");
      if (u.pathname !== "/" + nonce) throw Error("Invalid capture relay");
      const target = publicURL(u.searchParams.get("url") || ""),
        r = await publicFetch(target.href, (item.seconds + 40) * 1000);
      if (!r.ok) throw Error("Stream HTTP " + r.status);
      const type = r.headers.get("content-type") || "";
      if (/mpegurl/i.test(type) || /\.m3u8(?:$|\?)/i.test(target.href)) {
        const text = (await limitedBytes(r, 1000000)).toString("utf8");
        if (!text.startsWith("#EXTM3U")) throw Error("Invalid HLS playlist");
        const relayURL =
          "http://127.0.0.1:" + (relay.address() as any).port + "/" + nonce;
        res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
        res.end(rewritePlaylist(text, r.url || target.href, relayURL));
      } else {
        if (!r.body) throw Error("Empty stream");
        res.setHeader("Content-Type", type || "application/octet-stream");
        const input = Readable.fromWeb(r.body as any);
        let bytes = 0;
        input.on("data", (x: Buffer) => {
          bytes += x.length;
          if (bytes > 32 * 1048576)
            input.destroy(Error("Stream segment exceeds limit"));
        });
        res.on("close", () => input.destroy());
        await pipeline(input, res);
      }
    } catch {
      if (!res.headersSent) res.writeHead(502);
      res.end();
    }
  });
  await new Promise<void>((r) => relay.listen(0, "127.0.0.1", r));
  const input =
    "http://127.0.0.1:" +
    (relay.address() as any).port +
    "/" +
    nonce +
    "?url=" +
    encodeURIComponent(item.url);
  const encode =
    item.channel === "Television"
      ? ["-c:v", "copy", "-c:a", "aac", "-movflags", "+faststart", "-f", "mp4"]
      : [
          "-vn",
          "-ac",
          "1",
          "-ar",
          "16000",
          "-c:a",
          "libmp3lame",
          "-b:a",
          "48k",
          "-f",
          "mp3",
        ];
  const child = spawn(
    "ffmpeg",
    [
      "-nostdin",
      "-hide_banner",
      "-loglevel",
      "error",
      "-protocol_whitelist",
      "http,tcp,crypto",
      "-i",
      input,
      "-t",
      String(item.seconds),
      ...encode,
      "-y",
      file,
    ],
    { stdio: ["ignore", "ignore", "pipe"] },
  );
  captureRunning.set(item.id, { child, relay });
  let error = "";
  child.stderr.on("data", (x) => {
    error = (error + x).slice(-1500);
  });
  await putRecord({
    ...item,
    health: "Recording",
    lastStarted: new Date().toISOString(),
    lastError: "",
  });
  const sizeLimit = setInterval(() => {
    if (fs.existsSync(file) && fs.statSync(file).size > 32 * 1048576)
      child.kill("SIGTERM");
  }, 1000);
  const timeout = setTimeout(
    () => child.kill("SIGKILL"),
    (item.seconds + 45) * 1000,
  );
  let settled = false;
  const finish = async (code: number | null) => {
    if (settled) return;
    settled = true;
    clearTimeout(timeout);
    clearInterval(sizeLimit);
    relay.closeAllConnections();
    relay.close();
    try {
      const current = await getRecord(item.id);
      if (!current) return;
      const size = fs.existsSync(file) ? fs.statSync(file).size : 0;
      if (size < 500) {
        fs.rmSync(file, { force: true });
        await putRecord({
          ...current,
          health: current.enabled ? "Needs attention" : "Paused",
          lastError:
            "Recording failed. Check that the stream is reachable and supported.",
          nextCapture: new Date(Date.now() + 60000).toISOString(),
        });
        return;
      }
      const date = new Date().toISOString(),
        meta = {
          key,
          name:
            item.name +
            "-" +
            date.slice(0, 19).replace(/:/g, "-") +
            (item.channel === "Television" ? ".mp4" : ".mp3"),
          type: item.channel === "Television" ? "video/mp4" : "audio/mpeg",
          size,
        };
      await putRecord({
        id: "evidence-" + key,
        kind: "evidence",
        ...meta,
        broadcastId: item.id,
        date,
        expiresAt: new Date(
          Date.now() + item.retentionDays * 86400000,
        ).toISOString(),
      });
      const story = enrich({
        id: "capture-" + key,
        kind: "story",
        title: item.name + " · broadcast capture",
        body: "Recording saved. A transcript and analyst review are required.",
        source: item.name,
        channel: item.channel,
        language: item.language,
        region: item.region,
        date,
        url: item.url,
        programme: item.programme,
        presenter: item.presenter,
        broadcastTime: new Date().toLocaleTimeString("en-GB", {
          timeZone: "Africa/Windhoek",
        }),
        ...analyse("", item.language),
        sentiment: "Unclassified",
        risk: "Low",
        evidence: meta,
        transcription: item.transcribe ? "Queued" : "Not requested",
        verification: "Not assessed",
        status: "Open",
        approval: "Draft",
        sample: false,
      });
      await putRecord(story);
      if (item.transcribe)
        await putRecord({
          id: "transcription-" + key,
          kind: "transcription",
          storyId: story.id,
          key,
          language: item.language,
          status: "Queued",
          attempts: 0,
          nextAttempt: date,
          date,
        });
      await putRecord({
        ...current,
        health: current.enabled ? "Waiting for next clip" : "Paused",
        lastCapture: date,
        lastError: code === 0 ? "" : "Clip ended early; review recording.",
        nextCapture: new Date(Date.now() + 1000).toISOString(),
      });
    } catch (e: any) {
      console.error("Capture storage:", e.message);
    } finally {
      captureRunning.delete(item.id);
    }
  };
  child.once("close", (code) => {
    finish(code).catch((e) => console.error(e.message));
  });
  child.once("error", () => {
    finish(1).catch((e) => console.error(e.message));
  });
}
let busy = false;
export async function broadcastTick() {
  if (busy) return;
  busy = true;
  try {
    const all = await allRecords();
    for (const meta of all.filter(
      (x) =>
        x.kind === "evidence" &&
        x.broadcastId &&
        Date.parse(x.expiresAt) < Date.now(),
    )) {
      fs.rmSync(path.join(clips, meta.key), { force: true });
      await deleteRecord(meta.id);
      const story = await getRecord("capture-" + meta.key);
      if (story)
        await putRecord({ ...story, evidence: null, recordingExpired: true });
    }
    for (const item of all.filter((x) => x.kind === "broadcast" && x.enabled)) {
      if (captureRunning.size >= 2) break;
      if (!item.nextCapture || Date.parse(item.nextCapture) <= Date.now())
        await capture(item);
    }
  } finally {
    busy = false;
  }
}
let transcribing = false;
export async function transcriptionTick() {
  if (transcribing) return;
  transcribing = true;
  try {
    const job = (await allRecords()).find(
      (x) =>
        x.kind === "transcription" &&
        ["Queued", "Retry"].includes(x.status) &&
        Date.parse(x.nextAttempt) <= Date.now(),
    );
    if (!job) return;
    await putRecord({ ...job, status: "Processing" });
    try {
      const meta = await getRecord("evidence-" + job.key);
      if (!meta || !fs.existsSync(path.join(clips, job.key)))
        throw Error("Recording has expired or is missing.");
      const result = await transcribeBytes(
        fs.readFileSync(path.join(clips, job.key)),
        meta.type,
        job.language,
      );
      const story = await getRecord(job.storyId);
      if (story) {
        const updated = enrich({
          ...story,
          body: result.text,
          summary: "",
          ...analyse(result.text, job.language),
          transcription: "Completed",
          transcriptionProvider: result.provider,
          approval:
            story.approval === "Approved" ? "Pending review" : story.approval,
          reviewed: false,
        });
        await putRecord(updated);
        await queueAnalysis(updated);
        if (updated.risk === "High")
          await insertRecord({
            id: "alert-" + updated.id,
            kind: "notification",
            type: "Priority signal",
            title: updated.title,
            storyId: updated.id,
            date: new Date().toISOString(),
            read: false,
          });
      }
      await putRecord({
        ...job,
        status: "Completed",
        completedAt: new Date().toISOString(),
        error: "",
      });
    } catch (e: any) {
      const attempts = (job.attempts || 0) + 1;
      await putRecord({
        ...job,
        status: attempts >= 3 ? "Needs attention" : "Retry",
        attempts,
        error: e.message,
        nextAttempt: new Date(Date.now() + attempts * 60000).toISOString(),
      });
    }
  } finally {
    transcribing = false;
  }
}
export async function recoverCaptureJobs() {
  for (const job of (await allRecords()).filter(
    (x) => x.kind === "transcription" && x.status === "Processing",
  ))
    await putRecord({
      ...job,
      status: "Retry",
      nextAttempt: new Date().toISOString(),
    });
}
export function stopCaptures() {
  for (const { child, relay } of captureRunning.values()) {
    child.kill("SIGTERM");
    relay.closeAllConnections();
    relay.close();
  }
}
