import { allRecords, getRecord, putRecord, insertRecord } from "./store";
import { collectSource, collectSocial } from "./collection";
import { topicTrends, buildBriefing, namibiaDay } from "@/lib/intelligence";
import { audit, serviceActor } from "./access";
let running = false;
export async function runMonitoringJob(initiator = serviceActor) {
  if (running)
    return { busy: true, message: "Another monitoring job is running" };
  running = true;
  try {
    return await runJob(initiator);
  } finally {
    running = false;
  }
}
async function runJob(initiator = serviceActor) {
  const settings = await getRecord("monitoring-settings");
  if (settings?.paused)
    return {
      paused: true,
      message: "Monitoring is paused",
      date: new Date().toISOString(),
    };
  const existing = await getRecord("monitoring-job-lock");
  if (existing?.expires && Date.parse(existing.expires) > Date.now())
    return { busy: true, message: "Another monitoring job is already running" };
  await putRecord({
    id: "monitoring-job-lock",
    kind: "settings",
    expires: new Date(Date.now() + 240000).toISOString(),
  });
  const results: any[] = [];
  try {
    const all = await allRecords();
    const sources = all
      .filter((s) => s.kind === "source" && s.enabled && s.url)
      .sort((a, b) => (a.lastSync || "").localeCompare(b.lastSync || ""));
    for (const source of sources) {
      try {
        results.push(await collectSource(source.id));
      } catch (e) {
        results.push({ source: source.name, error: (e as Error).message });
      }
    }
    for (const cfg of all.filter(
      (x) =>
        x.kind === "settings" &&
        x.id.startsWith("integration-") &&
        x.enabled &&
        ["bluesky", "youtube", "facebook", "x"].includes(x.id.slice(12)),
    )) {
      try {
        results.push(await collectSocial(cfg.id.slice(12)));
      } catch (e) {
        results.push({ source: cfg.id, error: (e as Error).message });
      }
    }
    const after = await allRecords();
    const stories = after.filter((x) => x.kind === "story" && !x.sample);
    let notifications = 0;
    for (const s of stories.filter(
      (s) => !s.sample && s.risk === "High" && s.status !== "Resolved",
    )) {
      const added = await insertRecord({
        id: "alert-" + s.id,
        kind: "notification",
        type: "Priority signal",
        title: s.title,
        storyId: s.id,
        date: new Date().toISOString(),
        read: false,
      });
      if (added.length) notifications++;
    }
    const trends = topicTrends(stories);
    for (const trend of trends.filter((t) => t.emerging)) {
      const added = await insertRecord({
        id: "trend-" + namibiaDay() + "-" + trend.topic,
        kind: "notification",
        type: "Emerging trend",
        title: trend.topic + ": " + trend.current + " items in 24 hours",
        date: new Date().toISOString(),
        read: false,
      });
      if (added.length) notifications++;
    }
    const previous = namibiaDay(new Date(Date.now() - 86400000));
    const reportId = "daily-auto-" + previous;
    const report = buildBriefing(stories, previous);
    const saved = await getRecord(reportId);
    if (saved?.approval !== "Approved")
      await putRecord({
        ...report,
        id: reportId,
        kind: "report",
        automatic: true,
      });
    const result = {
      id: crypto.randomUUID(),
      kind: "job",
      date: new Date().toISOString(),
      results,
      notifications,
      reportDate: previous,
      reportCount: report.count,
      success: results.every((r) => !r.error),
      configuredSources: sources.length,
    };
    await putRecord(result);
    await audit(
      initiator,
      "Run monitoring",
      "automation",
      results.length +
        " source runs; " +
        notifications +
        " notifications; briefing " +
        previous,
    );
    return result;
  } finally {
    await putRecord({
      id: "monitoring-job-lock",
      kind: "settings",
      expires: new Date(0).toISOString(),
    });
  }
}
