import { allRecords, putRecord } from "./store";
import { publicFetch } from "./network";
let busy = false;
function channels() {
  return [
    process.env.NAMLENS_ALERT_URL ? "Webhook" : null,
    process.env.NAMLENS_EMAIL_KEY &&
    process.env.NAMLENS_EMAIL_FROM &&
    process.env.NAMLENS_EMAIL_TO
      ? "Email"
      : null,
  ].filter(Boolean) as string[];
}
async function deliver(n: any, channel: string) {
  if (channel === "Email") {
    const to = (process.env.NAMLENS_EMAIL_TO || "")
      .split(",")
      .map((x) => x.trim())
      .filter(Boolean);
    if (
      !to.length ||
      to.length > 10 ||
      to.some((x) => !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x))
    )
      throw Error("Configure 1–10 valid alert email recipients");
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + process.env.NAMLENS_EMAIL_KEY,
        "Idempotency-Key": "namlens-" + n.id,
      },
      body: JSON.stringify({
        from: process.env.NAMLENS_EMAIL_FROM,
        to,
        subject: ("Nam Lens: " + n.type).slice(0, 180),
        text: [
          n.title,
          n.date,
          "This is an automated media signal. Review the source before acting.",
          process.env.NAMLENS_PUBLIC_URL ||
            process.env.RENDER_EXTERNAL_URL ||
            "",
        ].join("\n\n"),
      }),
      signal: AbortSignal.timeout(10000),
    });
    if (!r.ok) {
      await r.body?.cancel();
      throw Error("Email service returned HTTP " + r.status);
    }
    const result: any = await r.json();
    if (!result.id) throw Error("Email provider did not return a message ID");
    return result.id;
  }
  const r = await publicFetch(process.env.NAMLENS_ALERT_URL!, 10000, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(process.env.NAMLENS_ALERT_TOKEN
        ? { Authorization: "Bearer " + process.env.NAMLENS_ALERT_TOKEN }
        : {}),
    },
    body: JSON.stringify({
      id: n.id,
      app: "Nam Lens",
      type: n.type,
      title: n.title,
      date: n.date,
      storyId: n.storyId || null,
    }),
  });
  await r.body?.cancel();
  if (!r.ok) throw Error("Notification service returned HTTP " + r.status);
  return "";
}
export async function deliveryTick() {
  const enabled = channels();
  if (busy || !enabled.length) return;
  busy = true;
  try {
    for (const n of (await allRecords())
      .filter(
        (x) =>
          x.kind === "notification" &&
          !x.sample &&
          x.delivery !== "Delivered" &&
          (x.deliveryAttempts || 0) < 5 &&
          (!x.nextDelivery || Date.parse(x.nextDelivery) <= Date.now()),
      )
      .slice(0, 5)) {
      const delivered = { ...(n.deliveredChannels || {}) },
        errors: string[] = [];
      for (const channel of enabled) {
        if (delivered[channel]) continue;
        try {
          const providerId = await deliver(n, channel);
          delivered[channel] = { date: new Date().toISOString(), providerId };
        } catch (e: any) {
          errors.push(e.message);
        }
      }
      const attempts = (n.deliveryAttempts || 0) + 1,
        done = enabled.every((x) => delivered[x]);
      await putRecord({
        ...n,
        deliveredChannels: delivered,
        delivery: done
          ? "Delivered"
          : attempts >= 5
            ? "Needs attention"
            : "Retry",
        deliveryAttempts: attempts,
        deliveryError: errors.join("; "),
        ...(done
          ? { deliveredAt: new Date().toISOString() }
          : {
              nextDelivery: new Date(
                Date.now() + Math.min(3600000, 60000 * 2 ** attempts),
              ).toISOString(),
            }),
      });
    }
  } finally {
    busy = false;
  }
}
