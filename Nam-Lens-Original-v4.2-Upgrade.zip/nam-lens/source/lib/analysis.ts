export const regions = [
  "National",
  "Erongo",
  "Hardap",
  "ǁKaras",
  "Kavango East",
  "Kavango West",
  "Khomas",
  "Kunene",
  "Ohangwena",
  "Omaheke",
  "Omusati",
  "Oshana",
  "Oshikoto",
  "Otjozondjupa",
  "Zambezi",
  "International",
];
export const channels = ["Print", "Radio", "Television", "Online", "Social"];
export const languages = [
  "English",
  "Oshiwambo",
  "Oshindonga",
  "Oshikwanyama",
  "Setswana",
  "Otjiherero",
  "Afrikaans",
  "German",
  "Khoekhoegowab",
  "Rukwangali",
  "Silozi",
  "Other",
];
export function analyse(text: string, language = "English") {
  const dictionaries: Record<
    string,
    { positive: string[]; negative: string[]; negation: string[] }
  > = {
    English: {
      positive: [
        "improve",
        "success",
        "growth",
        "support",
        "launch",
        "benefit",
        "investment",
        "opportunity",
        "progress",
        "achieve",
        "welcome",
        "expand",
        "boost",
      ],
      negative: [
        "crisis",
        "failure",
        "protest",
        "shortage",
        "corruption",
        "delay",
        "flood",
        "outage",
        "misinformation",
        "disruption",
        "unemployment",
        "concern",
        "complaint",
        "drought",
        "risk",
      ],
      negation: ["no", "not", "never", "without"],
    },
    Afrikaans: {
      positive: [
        "verbeter",
        "sukses",
        "groei",
        "ondersteun",
        "voordeel",
        "belegging",
        "geleentheid",
        "vordering",
      ],
      negative: [
        "krisis",
        "misluk",
        "protes",
        "tekort",
        "korrupsie",
        "vertraging",
        "vloede",
        "werkloos",
        "klagte",
        "droogte",
        "risiko",
      ],
      negation: ["geen", "nie", "sonder"],
    },
    German: {
      positive: [
        "verbesser",
        "erfolg",
        "wachstum",
        "unterstütz",
        "vorteil",
        "investition",
        "chance",
        "fortschritt",
      ],
      negative: [
        "krise",
        "versagen",
        "protest",
        "mangel",
        "korruption",
        "verzöger",
        "flut",
        "arbeitslos",
        "beschwer",
        "dürre",
        "risiko",
      ],
      negation: ["kein", "keine", "nicht", "ohne"],
    },
  };
  const dict = dictionaries[language];
  const lower = text.toLowerCase();
  const tokens: string[] = Array.from(lower.match(/[\p{L}]+/gu) || []);
  let score = 0;
  const matches: string[] = [];
  if (dict)
    tokens.forEach((word, i) => {
      const positive = dict.positive.some((w) => word.startsWith(w));
      const negative = dict.negative.some((w) => word.startsWith(w));
      if (!positive && !negative) return;
      const negated = tokens
        .slice(Math.max(0, i - 3), i)
        .some((w) => dict.negation.includes(w));
      score += (positive ? 1 : -1) * (negated ? -1 : 1);
      matches.push((negated ? "negated " : "") + word);
    });
  const topics: Record<string, string[]> = {
    "Public services": [
      "water",
      "electricity",
      "service",
      "outage",
      "wasser",
      "diens",
    ],
    Education: [
      "school",
      "education",
      "student",
      "training",
      "skool",
      "schule",
    ],
    "Economy & jobs": [
      "job",
      "econom",
      "investment",
      "unemployment",
      "tourism",
      "werkloos",
      "arbeit",
    ],
    Health: ["health", "hospital", "clinic", "gesund", "kliniek"],
    Environment: ["flood", "drought", "climate", "rain", "flut", "droogte"],
    Governance: [
      "policy",
      "government",
      "corruption",
      "accountability",
      "regierung",
      "regering",
    ],
    "Information integrity": [
      "misinformation",
      "disinformation",
      "false",
      "rumour",
    ],
  };
  const topic =
    Object.entries(topics).find(([, words]) =>
      words.some((w) => lower.includes(w)),
    )?.[0] || "General";
  const urgent = [
    "crisis",
    "flood",
    "outage",
    "shortage",
    "protest",
    "corruption",
    "krisis",
    "krise",
    "mangel",
    "tekort",
  ].filter((w) => lower.includes(w));
  return {
    sentiment: dict
      ? score < 0
        ? "Negative"
        : score > 0
          ? "Positive"
          : "Neutral"
      : "Unclassified",
    risk:
      urgent.length > 1
        ? "High"
        : urgent.length === 1 || score < 0
          ? "Medium"
          : "Low",
    topic,
    analysisReason: dict
      ? `Language: ${language}. Lexicon matches: ${matches.join(", ") || "none"}. Nearby negation is checked; context and sarcasm still need review.`
      : "This language is not covered by the local lexicon. A language reviewer must classify the item.",
    analysisMethod: dict ? "Context-aware lexicon" : "Human review required",
    confidence: null,
    reviewed: false,
  };
}
