import { zipSync, strToU8 } from "fflate";
const esc = (x: any) =>
  String(x ?? "")
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
export function reportTable(items: any[], broadcast = false) {
  const headers = broadcast
    ? [
        "Station",
        "Programme",
        "Time",
        "Topic / presenter",
        "Brief summary",
        "Quoted source / role",
        "Sentiment",
        "Institutions / organisations",
        "Recommendation",
      ]
    : [
        "Publication / channel",
        "Page / link",
        "Headline",
        "Brief summary",
        "Quoted source / role",
        "Sentiment",
        "Institutions / organisations",
        "Recommendation",
      ];
  const rows = items.map((s) =>
    broadcast
      ? [
          s.source,
          s.programme || "—",
          s.broadcastTime || "—",
          s.title + (s.presenter ? "\nPresenter: " + s.presenter : ""),
          (s.sample ? "[FICTIONAL SAMPLE] " : "") + (s.summary || s.body),
          [s.quotedPerson, s.quotedRole, s.statementType]
            .filter(Boolean)
            .join("\n") || "—",
          s.sentiment,
          (s.institutions || []).join("\n") || "—",
          s.recommendation || "None recorded",
        ]
      : [
          s.source + "\n" + s.channel,
          s.pageNumber || s.url || "—",
          s.title,
          (s.sample ? "[FICTIONAL SAMPLE] " : "") + (s.summary || s.body),
          [s.quotedPerson, s.quotedRole, s.statementType]
            .filter(Boolean)
            .join("\n") || "—",
          s.sentiment,
          (s.institutions || []).join("\n") || "—",
          s.recommendation || "None recorded",
        ],
  );
  return { headers, rows };
}
export function reportSections(report: any) {
  const items = report.items || [];
  return [
    {
      name: "PRINT & DIGITAL MEDIA MONITORING",
      ...reportTable(
        items.filter((s: any) => !["Radio", "Television"].includes(s.channel)),
      ),
    },
    {
      name: "RADIO & TELEVISION MEDIA MONITORING",
      ...reportTable(
        items.filter((s: any) => ["Radio", "Television"].includes(s.channel)),
        true,
      ),
    },
  ];
}
export function createDocx(report: any) {
  const para = (t: string, bold = false) =>
    `<w:p><w:r>${bold ? "<w:rPr><w:b/></w:rPr>" : ""}<w:t xml:space="preserve">${esc(t)}</w:t></w:r></w:p>`;
  const table = (section: any) => {
    const width = Math.floor(15400 / section.headers.length);
    const row = (values: any[], head = false) =>
      `<w:tr>${head ? "<w:trPr><w:tblHeader/></w:trPr>" : ""}${values.map((v, i) => `<w:tc><w:tcPr><w:tcW w:w="${width}" w:type="dxa"/>${head ? '<w:shd w:fill="183B54"/>' : ""}</w:tcPr><w:p><w:r><w:rPr><w:sz w:val="16"/>${head ? '<w:b/><w:color w:val="FFFFFF"/>' : v === "Positive" ? '<w:color w:val="16825F"/>' : v === "Negative" ? '<w:color w:val="C5404C"/>' : ""}</w:rPr><w:t xml:space="preserve">${esc(v)}</w:t></w:r></w:p></w:tc>`).join("")}</w:tr>`;
    return `<w:tbl><w:tblPr><w:tblW w:w="15400" w:type="dxa"/><w:tblBorders>${["top", "left", "bottom", "right", "insideH", "insideV"].map((p) => `<w:${p} w:val="single" w:sz="4" w:color="DEE6EB"/>`).join("")}</w:tblBorders></w:tblPr><w:tblGrid>${section.headers.map(() => `<w:gridCol w:w="${width}"/>`).join("")}</w:tblGrid>${row(section.headers, true)}${section.rows.map((r: any) => row(r)).join("")}</w:tbl>`;
  };
  const sections = reportSections(report);
  const body =
    para("NAM LENS", true) +
    para("DAILY MONITORING REPORT — " + report.date) +
    para(
      `${report.count} recorded stories; ${report.samples || 0} fictional samples. Approval: ${report.approval || "Draft"}.`,
    ) +
    sections
      .map(
        (s) =>
          para(s.name, true) +
          (s.rows.length
            ? table(s)
            : para("No coverage recorded in this section.")),
      )
      .join("") +
    para(
      "Notes: Negative = red; Positive = green; Neutral = black. Classifications require review. This report covers saved media items only. Unverified claims are not established misinformation.",
    ) +
    `<w:sectPr><w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/><w:pgMar w:top="720" w:right="720" w:bottom="720" w:left="720"/></w:sectPr>`;
  const files: any = {
    "[Content_Types].xml": strToU8(
      '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>',
    ),
    "_rels/.rels": strToU8(
      '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
    ),
    "word/document.xml": strToU8(
      '<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' +
        body +
        "</w:body></w:document>",
    ),
  };
  return zipSync(files);
}
export function createXlsx(report: any) {
  const sections = reportSections(report);
  const sheets = sections.map((s, i) => ({
    name: i === 0 ? "Print and digital" : "Radio and television",
    rows: [
      ["Nam Lens — " + report.date],
      [
        `${report.count} stories; ${report.samples || 0} fictional samples; ${report.approval || "Draft"}`,
      ],
      s.headers,
      ...s.rows,
    ],
  }));
  const files: any = {};
  const col = (n: number) => String.fromCharCode(65 + n);
  sheets.forEach((s, i) => {
    files[`xl/worksheets/sheet${i + 1}.xml`] = strToU8(
      `<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="3" topLeftCell="A4" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>${Array.from({ length: 9 }, (_, n) => `<col min="${n + 1}" max="${n + 1}" width="${n === 3 || n === 4 ? 45 : 24}" customWidth="1"/>`).join("")}</cols><sheetData>${s.rows.map((r: any[], ri) => `<row r="${ri + 1}"${ri >= 3 ? ' ht="110" customHeight="1"' : ""}>${r.map((v, n) => `<c r="${col(n)}${ri + 1}" t="inlineStr" s="${ri === 2 ? 1 : v === "Negative" ? 2 : v === "Positive" ? 3 : 0}"><is><t xml:space="preserve">${esc(v)}</t></is></c>`).join("")}</row>`).join("")}</sheetData><autoFilter ref="A3:${col(s.rows[2].length - 1)}${Math.max(3, s.rows.length)}"/><pageSetup orientation="landscape" paperSize="9" fitToWidth="1"/></worksheet>`,
    );
  });
  files["xl/workbook.xml"] = strToU8(
    `<?xml version="1.0"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets.map((s, i) => `<sheet name="${s.name}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("")}</sheets></workbook>`,
  );
  files["xl/_rels/workbook.xml.rels"] = strToU8(
    `<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((s, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join("")}<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`,
  );
  files["xl/styles.xml"] = strToU8(
    `<?xml version="1.0"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="4"><font><sz val="10"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="10"/><name val="Calibri"/></font><font><color rgb="FFC5404C"/><sz val="10"/><name val="Calibri"/></font><font><color rgb="FF16825F"/><sz val="10"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF183B54"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="4">${[0, 1, 2, 3].map((n) => `<xf fontId="${n}" fillId="${n === 1 ? 2 : 0}" borderId="0" numFmtId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>`).join("")}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`,
  );
  files["_rels/.rels"] = strToU8(
    '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
  );
  files["[Content_Types].xml"] = strToU8(
    `<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((s, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}</Types>`,
  );
  return zipSync(files);
}
export async function createPDF(
  report: any,
  fontBytes: ArrayBuffer | Uint8Array,
) {
  const { PDFDocument, rgb } = await import("pdf-lib");
  const fontkit = (await import("@pdf-lib/fontkit")).default;
  const pdf = await PDFDocument.create();
  pdf.registerFontkit(fontkit);
  const font = await pdf.embedFont(fontBytes, { subset: true });
  const sections = reportSections(report);
  const width = 842,
    height = 595,
    margin = 28;
  let page: any,
    y = 0;
  const clean = (s: any) =>
    String(s ?? "").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "");
  function lines(text: any, maxWidth: number, size = 7) {
    const result: string[] = [];
    for (const paragraph of clean(text).split("\n")) {
      let line = "";
      for (const word of paragraph.split(/\s+/)) {
        if (
          font.widthOfTextAtSize(line + (line ? " " : "") + word, size) >
            maxWidth &&
          line
        ) {
          result.push(line);
          line = word;
        } else line += (line ? " " : "") + word;
        if (font.widthOfTextAtSize(line, size) > maxWidth) {
          let part = "";
          for (const c of line) {
            if (font.widthOfTextAtSize(part + c, size) > maxWidth && part) {
              result.push(part);
              part = c;
            } else part += c;
          }
          line = part;
        }
      }
      result.push(line);
    }
    return result;
  }
  function newPage(title: string) {
    page = pdf.addPage([width, height]);
    y = height - margin;
    page.drawRectangle({
      x: 0,
      y: height - 8,
      width,
      height: 8,
      color: rgb(0.09, 0.24, 0.34),
    });
    page.drawText("NAM LENS", {
      x: margin,
      y: y - 10,
      size: 13,
      font,
      color: rgb(0.09, 0.24, 0.34),
    });
    y -= 32;
    page.drawText(title + " — " + report.date, { x: margin, y, size: 9, font });
    y -= 18;
    page.drawText(
      `${report.count} records | ${report.samples || 0} fictional samples | ${report.approval || "Draft"}`,
      { x: margin, y, size: 7, font },
    );
    y -= 20;
  }
  for (const section of sections) {
    newPage(section.name);
    const cw = (width - margin * 2) / section.headers.length;
    const head = () => {
      page.drawRectangle({
        x: margin,
        y: y - 29,
        width: width - margin * 2,
        height: 29,
        color: rgb(0.09, 0.24, 0.34),
      });
      section.headers.forEach((h, i) =>
        lines(h, cw - 9, 7)
          .slice(0, 3)
          .forEach((l, k) =>
            page.drawText(l, {
              x: margin + i * cw + 4,
              y: y - 10 - k * 8,
              size: 7,
              font,
              color: rgb(1, 1, 1),
            }),
          ),
      );
      y -= 29;
    };
    head();
    if (!section.rows.length) {
      page.drawText("No recorded coverage in this section.", {
        x: margin,
        y: y - 22,
        size: 9,
        font,
      });
      continue;
    }
    for (const row of section.rows) {
      const cols = row.map((v) => lines(v, cw - 9));
      let pos = 0;
      const total = Math.max(...cols.map((c) => c.length));
      while (pos < total) {
        if (y < margin + 22) {
          newPage(section.name + " (continued)");
          head();
        }
        const take = Math.min(
          total - pos,
          Math.max(1, Math.floor((y - margin - 10) / 9)),
        );
        const rh = take * 9 + 9;
        page.drawRectangle({
          x: margin,
          y: y - rh,
          width: width - margin * 2,
          height: rh,
          borderColor: rgb(0.86, 0.9, 0.92),
          borderWidth: 0.5,
        });
        cols.forEach((list, i) => {
          const val = row[i];
          const color =
            val === "Negative"
              ? rgb(0.77, 0.25, 0.3)
              : val === "Positive"
                ? rgb(0.09, 0.5, 0.36)
                : rgb(0.16, 0.22, 0.27);
          for (let k = 0; k < take; k++)
            if (list[pos + k])
              page.drawText(list[pos + k], {
                x: margin + i * cw + 4,
                y: y - 11 - k * 9,
                size: 7,
                font,
                color,
              });
          page.drawLine({
            start: { x: margin + i * cw, y },
            end: { x: margin + i * cw, y: y - rh },
            color: rgb(0.86, 0.9, 0.92),
            thickness: 0.4,
          });
        });
        y -= rh;
        pos += take;
      }
    }
  }
  pdf
    .getPages()
    .forEach((p, i) =>
      p.drawText(
        `Saved coverage only. Suggestions require human review.  |  Page ${i + 1} of ${pdf.getPageCount()}`,
        { x: margin, y: 14, size: 6.5, font, color: rgb(0.5, 0.56, 0.61) },
      ),
    );
  return pdf.save();
}
