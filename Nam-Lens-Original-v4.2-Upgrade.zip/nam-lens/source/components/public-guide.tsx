import React from "react";
export default function PublicGuide({ back }: { back?: () => void }) {
  return (
    <div className="public-guide">
      <header className="landing-header">
        <a
          href="/"
          onClick={
            back
              ? (e) => {
                  e.preventDefault();
                  back();
                }
              : undefined
          }
          className="landing-brand"
        >
          <img src="/favicon.svg" alt="" />
          <strong>
            Nam <em>Lens</em>
          </strong>
        </a>
        <a
          href="/"
          className="button"
          onClick={
            back
              ? (e) => {
                  e.preventDefault();
                  back();
                }
              : undefined
          }
        >
          ← Back
        </a>
      </header>
      <main>
        <div className="eyebrow">YOUR NAM LENS GUIDE</div>
        <h1>A clearer view, one story at a time.</h1>
        <p className="guide-intro">
          Nam Lens brings Namibia’s news, broadcast recordings and follow-up
          work into one shared media desk.
        </p>
        <nav className="guide-links" aria-label="Guide sections">
          <a href="#start">Getting started</a>
          <a href="#stories">News & stories</a>
          <a href="#voices">Language studio</a>
          <a href="#reports">Reports</a>
        </nav>
        <div className="guide-grid">
          <section id="start">
            <span>01 / GET STARTED</span>
            <h2>Your own account.</h2>
            <p>
              Choose Create account on the home page. The first account on a new
              local workspace becomes its owner. Later accounts wait for the
              owner to approve access in Team & approvals. Log in with your
              email and password.
            </p>
            <p>
              Use the Menu button to open navigation. On a computer, moving to
              the left edge also reveals it. Pin the menu if you want it to stay
              open.
            </p>
          </section>
          <section id="stories">
            <span>02 / COLLECT & CHECK</span>
            <h2>Every story has a source.</h2>
            <p>
              Add a story means saving a news article, social post or broadcast
              transcript. Follow the short steps: enter its headline and text,
              add where and when it appeared, then check the details and attach
              evidence.
            </p>
            <p>
              Sources is your list of media outlets. Connect a public news feed
              or import your stories with the spreadsheet template. Watchlists
              find stories that mention your chosen words. Sample stories are
              clearly marked as fictional.
            </p>
          </section>
          <section id="voices">
            <span>03 / MANY VOICES</span>
            <h2>Listen. Transcribe. Review.</h2>
            <p>
              Open Language studio to record or upload audio. Choose the
              language actually spoken. If an AI connection supports it, request
              a draft transcript; listen again and correct names, places and
              wording before saving.
            </p>
            <p>
              Oshiwambo’s dialects are listed separately. The optional Oshiwambo
              AI model is experimental and needs fluent-speaker checks. Other
              indigenous languages remain available for listening and human
              transcription until a suitable speech service is connected. AI
              availability and accuracy are separate things.
            </p>
            <p>
              Recordings stay linked to their stories. Your saved transcript is
              preserved as you move through the steps. Audio leaves this
              computer only when you use a remote connected speech service.
              Microphone access needs a compatible browser and your permission.
            </p>
          </section>
          <section id="reports">
            <span>04 / REVIEW & RESPOND</span>
            <h2>Turn stories into useful action.</h2>
            <p>
              Sentiment describes a story’s tone: positive, negative or neutral.
              Priority means how urgently a story needs attention. A suggestion
              needs a person’s judgement; a negative story does not prove a
              false claim or a crisis.
            </p>
            <p>
              Create a daily report, check it, then download a PDF, Word
              document or spreadsheet. Reports are saved snapshots. Recreate a
              report after changing its stories. Follow-up actions record who
              should respond, the due date and the outcome.
            </p>
            <p>
              In Settings, download a full backup before upgrading. Keep the
              app’s start window open for scheduled monitoring. You can read
              this guide without an account.
            </p>
          </section>
        </div>
      </main>
      <footer>
        <span>Nam Lens · Many voices. One clear view.</span>
        <a href="/">Home</a>
      </footer>
    </div>
  );
}
