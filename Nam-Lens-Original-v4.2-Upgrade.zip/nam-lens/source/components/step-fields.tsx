import React, {
  Children,
  isValidElement,
  useEffect,
  useRef,
  useState,
} from "react";
function flatten(children: React.ReactNode): React.ReactNode[] {
  return Children.toArray(children).flatMap((c) =>
    isValidElement(c) && c.type === React.Fragment
      ? flatten((c.props as any).children)
      : [c],
  );
}
/** Keep controlled values mounted between steps; validate all fields before the real save. */
export default function StepFields({
  children,
  names = ["The basics", "More details", "Review & finish"],
  size = 6,
}: {
  children: React.ReactNode;
  names?: string[];
  size?: number;
}) {
  const fields = flatten(children),
    count = Math.max(1, Math.ceil(fields.length / size)),
    [step, setStep] = useState(0),
    root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    setStep(0);
  }, [count]);
  useEffect(() => {
    const form = root.current?.closest("form");
    if (!form) return;
    const old = form.noValidate;
    form.noValidate = true;
    const submits = Array.from(
      form.querySelectorAll<HTMLButtonElement>(
        'button:not([type]),button[type="submit"]',
      ),
    );
    submits.forEach((b) => (b.hidden = step < count - 1));
    const validate = (n: number) => {
      const section = root.current?.querySelector(`[data-step="${n}"]`);
      const inputs = Array.from(
        section?.querySelectorAll<HTMLInputElement>("input,select,textarea") ||
          [],
      );
      const invalid = inputs.find((i) => !i.disabled && !i.checkValidity());
      if (invalid) {
        setStep(n);
        requestAnimationFrame(() => {
          invalid.focus();
          invalid.reportValidity();
        });
        return false;
      }
      return true;
    };
    const intercept = (e: Event) => {
      if (step < count - 1) {
        e.preventDefault();
        e.stopImmediatePropagation();
        if (validate(step)) setStep(step + 1);
      } else
        for (let n = 0; n < count; n++) {
          if (!validate(n)) {
            e.preventDefault();
            e.stopImmediatePropagation();
            break;
          }
        }
    };
    form.addEventListener("submit", intercept, true);
    return () => {
      form.removeEventListener("submit", intercept, true);
      form.noValidate = old;
      submits.forEach((b) => (b.hidden = false));
    };
  }, [step, count]);
  function next() {
    const inputs = Array.from(
      root.current
        ?.querySelector(`[data-step="${step}"]`)
        ?.querySelectorAll<HTMLInputElement>("input,select,textarea") || [],
    );
    const invalid = inputs.find((i) => !i.disabled && !i.checkValidity());
    if (invalid) {
      invalid.focus();
      invalid.reportValidity();
      return;
    }
    setStep((s) => Math.min(count - 1, s + 1));
  }
  return (
    <div className="step-flow" ref={root}>
      <div
        className="step-progress"
        aria-label={`Step ${step + 1} of ${count}`}
      >
        <span>
          Step {step + 1} of {count}
        </span>
        <strong>{names[step] || "Final details"}</strong>
        <div>
          {Array.from({ length: count }, (_, i) => (
            <i key={i} className={i <= step ? "done" : ""} />
          ))}
        </div>
      </div>
      {Array.from({ length: count }, (_, i) => (
        <div
          key={i}
          className="form-grid step-section"
          data-step={i}
          hidden={i !== step}
        >
          {fields.slice(i * size, (i + 1) * size)}
        </div>
      ))}
      {count > 1 && (
        <div className="step-actions">
          <button
            type="button"
            className="button"
            disabled={step === 0}
            onClick={() => setStep((s) => s - 1)}
          >
            Back
          </button>
          {step < count - 1 ? (
            <button type="button" className="primary" onClick={next}>
              Next →
            </button>
          ) : (
            <span>Ready to save. You can go back to check your details.</span>
          )}
        </div>
      )}
    </div>
  );
}
