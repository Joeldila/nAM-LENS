import React, { useEffect, useRef, useState } from "react";
import {
  Mic,
  Square,
  Upload,
  ArrowRight,
  FileText,
  Check,
  RefreshCw,
} from "lucide-react";
const empty = {
  text: "",
  language: "English",
  segments: [] as any[],
  evidence: null as any,
  provider: "Human transcript",
  originalText: "",
  reviewed: false,
};
async function request(url: string, data?: any) {
  const r = await fetch(
    url,
    data
      ? {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        }
      : undefined,
  );
  const j = await r.json();
  if (!r.ok) throw Error(j.error || "Could not save");
  return j;
}
const time = (n: number) =>
  Math.floor(n / 60) + ":" + String(Math.floor(n % 60)).padStart(2, "0");
export default function LanguageStudio({
  notice,
  addCaptured,
  canEdit,
}: {
  notice: (s: string) => void;
  addCaptured: (s: any) => void;
  canEdit: boolean;
}) {
  const [draft, setDraft] = useState<any>(empty),
    [ready, setReady] = useState(false),
    [status, setStatus] = useState<any>(null),
    [step, setStep] = useState(0),
    [busy, setBusy] = useState(false),
    [recording, setRecording] = useState(false),
    [audioUrl, setAudioUrl] = useState(""),
    [saved, setSaved] = useState(""),
    [remote, setRemote] = useState(""),
    [duration, setDuration] = useState(0);
  const media = useRef<MediaStream | null>(null),
    recorder = useRef<MediaRecorder | null>(null),
    chunks = useRef<Blob[]>([]),
    player = useRef<HTMLAudioElement>(null),
    urlRef = useRef(""),
    unmounted = useRef(false),
    requestVersion = useRef(0),
    saveChain = useRef(Promise.resolve()),
    draftRef = useRef(draft),
    lastSaved = useRef(JSON.stringify(empty)),
    readyRef = useRef(false);
  draftRef.current = draft;
  function audio(blob: Blob) {
    if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    const u = URL.createObjectURL(blob);
    urlRef.current = u;
    setAudioUrl(u);
  }
  async function loadAudio(e: any) {
    if (!e) return;
    const r = await fetch("/api/evidence?key=" + encodeURIComponent(e.key));
    if (!r.ok) throw Error("Saved recording could not be opened");
    audio(await r.blob());
  }
  useEffect(() => {
    unmounted.current = false;
    Promise.all([
      request("/api/speech"),
      canEdit ? request("/api/capture-draft") : Promise.resolve({}),
    ])
      .then(async ([s, d]) => {
        if (unmounted.current) return;
        setStatus(s);
        if (d.text || d.evidence) {
          const restored = { ...empty, ...d };
          lastSaved.current = JSON.stringify(restored);
          setDraft(restored);
          setSaved("Saved draft restored");
          await loadAudio(d.evidence);
        }
        readyRef.current = true;
        setReady(true);
      })
      .catch((e) => {
        notice(e.message);
        setReady(true);
      });
    return () => {
      unmounted.current = true;
      if (
        canEdit &&
        readyRef.current &&
        JSON.stringify(draftRef.current) !== lastSaved.current
      ) {
        const payload = { ...draftRef.current };
        saveChain.current = saveChain.current
          .catch(() => {})
          .then(() => request("/api/capture-draft", payload))
          .then(() => {})
          .catch(() => {});
      }

      media.current?.getTracks().forEach((t) => t.stop());
      if (recorder.current?.state === "recording") recorder.current.stop();
      if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    };
  }, []);
  useEffect(() => {
    if (!ready || !canEdit || JSON.stringify(draft) === lastSaved.current)
      return;
    const version = ++requestVersion.current;
    setSaved("Saving draft…");
    const t = setTimeout(() => {
      const payload = { ...draft };
      saveChain.current = saveChain.current
        .catch(() => {})
        .then(() => request("/api/capture-draft", payload))
        .then(() => {
          lastSaved.current = JSON.stringify(payload);
          if (!unmounted.current && version === requestVersion.current)
            setSaved("Draft saved");
        })
        .catch((e) => {
          if (!unmounted.current) {
            setSaved("Draft could not be saved");
            notice(e.message);
          }
        });
    }, 700);
    return () => clearTimeout(t);
  }, [draft, ready]);
  useEffect(() => {
    if (!recording) return;
    setDuration(0);
    const t = setInterval(() => setDuration((d) => d + 1), 1000);
    return () => clearInterval(t);
  }, [recording]);
  async function act(fn: () => Promise<any>) {
    setBusy(true);
    try {
      await fn();
    } catch (e: any) {
      notice(e.message);
    } finally {
      setBusy(false);
    }
  }
  async function upload(file: File) {
    if (!file.type) {
      const ext = file.name.split(".").pop()?.toLowerCase() || "",
        types: Record<string, string> = {
          mp3: "audio/mpeg",
          wav: "audio/wav",
          m4a: "audio/mp4",
          ogg: "audio/ogg",
          webm: "audio/webm",
          mp4: "video/mp4",
        };
      if (types[ext]) file = new File([file], file.name, { type: types[ext] });
    }

    if (file.size > 10485760) throw Error("Choose a recording below 10 MB");
    if (!/^(audio|video)\//.test(file.type))
      throw Error("Choose an audio or video recording");
    const fd = new FormData();
    fd.append("file", file);
    const r = await fetch("/api/evidence", { method: "POST", body: fd });
    const e = await r.json();
    if (!r.ok) throw Error(e.error);
    audio(file);
    setDraft((d: any) => ({
      ...d,
      evidence: e,
      segments: [],
      text: "",
      originalText: "",
      provider: "Human transcript",
      reviewed: false,
    }));
    setStep(1);
    notice("Recording saved. Choose its language and listen again.");
  }
  async function record() {
    await act(async () => {
      if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder)
        throw Error(
          "Microphone recording is unavailable here. Upload an audio recording instead.",
        );
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      media.current = stream;
      chunks.current = [];
      const rec = new MediaRecorder(stream);
      recorder.current = rec;
      let size = 0;
      rec.ondataavailable = (e) => {
        if (e.data.size) {
          chunks.current.push(e.data);
          size += e.data.size;
          if (size > 9 * 1024 * 1024 && rec.state === "recording") {
            rec.stop();
            notice("Recording stopped before the file limit.");
          }
        }
      };
      rec.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        if (unmounted.current) return;
        setRecording(false);
        const type = rec.mimeType.split(";")[0],
          blob = new Blob(chunks.current, { type });
        const file = new File(
          [blob],
          "Nam-Lens-recording." +
            (type.includes("mp4")
              ? "m4a"
              : type.includes("ogg")
                ? "ogg"
                : "webm"),
          { type },
        );
        act(() => upload(file));
      };
      rec.start(1000);
      setRecording(true);
      notice("Microphone recording started");
    });
  }
  async function transcribe() {
    await act(async () => {
      if (!draft.evidence) throw Error("Record or upload audio first");
      const r = await fetch("/api/evidence?key=" + draft.evidence.key);
      if (!r.ok) throw Error("Recording could not be loaded");
      const blob = await r.blob(),
        form = new FormData();
      form.append(
        "file",
        new File([blob], draft.evidence.name, { type: draft.evidence.type }),
      );
      form.append("language", draft.language);
      const res = await fetch("/api/transcribe", {
          method: "POST",
          body: form,
        }),
        j = await res.json();
      if (!res.ok) throw Error(j.error);
      setDraft((d: any) => ({
        ...d,
        text: j.text,
        originalText: j.text,
        provider: j.provider,
        segments: j.segments || [],
        reviewed: false,
      }));
      setStep(2);
      notice("AI draft ready. Listen and check the wording before saving.");
    });
  }
  const language = status?.languages?.find(
    (l: any) => l.name === draft.language,
  );
  function editText(text: string) {
    setDraft((d: any) => ({ ...d, text, segments: [], reviewed: false }));
  }
  return (
    <section className="panel capture-panel language-studio">
      <div className="capture-toolbar">
        <h3>Language studio</h3>
        <span className="studio-draft" role="status">
          {saved}
        </span>
      </div>
      <div className="step-progress">
        <span>Step {step + 1} of 3</span>
        <strong>
          {["Bring in a voice", "Listen & transcribe", "Check the words"][step]}
        </strong>
        <div>
          {[0, 1, 2].map((n) => (
            <i key={n} className={n <= step ? "done" : ""} />
          ))}
        </div>
      </div>
      {step === 0 && (
        <>
          <p>
            Record a voice or choose an existing radio or interview recording.
          </p>
          <div className="record-actions">
            <button
              className={recording ? "danger-button" : "primary"}
              disabled={busy || !canEdit}
              onClick={recording ? () => recorder.current?.stop() : record}
            >
              {recording ? <Square size={17} /> : <Mic size={17} />}{" "}
              {recording ? "Stop · " + time(duration) : "Record audio"}
            </button>
            <label className="button">
              <Upload size={16} /> Upload recording
              <input
                className="hidden-file"
                type="file"
                accept="audio/*,video/mp4,video/webm"
                disabled={busy || recording || !canEdit}
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) act(() => upload(f));
                  e.target.value = "";
                }}
              />
            </label>
          </div>
          <details>
            <summary>Use an online recording</summary>
            <label className="capture-label">
              Direct recording link
              <input
                aria-label="Direct recording link"
                type="url"
                value={remote}
                onChange={(e) => setRemote(e.target.value)}
                placeholder="https://…"
              />
            </label>
            <button
              className="button"
              disabled={busy || !remote || !canEdit}
              onClick={() =>
                act(async () => {
                  const e = await request("/api/recording", { url: remote });
                  await loadAudio(e);
                  setDraft((d: any) => ({
                    ...d,
                    evidence: e,
                    text: "",
                    originalText: "",
                    segments: [],
                    reviewed: false,
                  }));
                  setStep(1);
                })
              }
            >
              Get recording
            </button>
          </details>
          {draft.evidence && (
            <p className="fine-print">Saved recording: {draft.evidence.name}</p>
          )}
          <button
            className="text-button"
            disabled={recording || busy || !canEdit}
            onClick={() => setStep(1)}
          >
            Continue with a written transcript →
          </button>
        </>
      )}
      {step >= 1 && (
        <>
          {audioUrl && (
            <audio ref={player} controls src={audioUrl} preload="metadata" />
          )}
          <label className="capture-label">
            Language spoken
            <select
              aria-label="Language spoken"
              value={draft.language}
              disabled={busy}
              onChange={(e) =>
                setDraft((d: any) => ({
                  ...d,
                  language: e.target.value,
                  reviewed: false,
                }))
              }
            >
              {status?.languages?.map((l: any) => (
                <option key={l.name}>{l.name}</option>
              ))}
            </select>
          </label>
          {step === 1 && (
            <>
              <div
                className={
                  "language-status " + (!language?.available ? "waiting" : "")
                }
              >
                <strong>
                  {language?.available
                    ? language.experimental
                      ? "Experimental AI available"
                      : "AI transcription available"
                    : "Human transcription available"}
                </strong>
                <p>
                  {language?.available
                    ? language.experimental
                      ? "This model needs careful checking by a fluent speaker."
                      : "Create a draft, then listen and correct it."
                    : "Listen and enter the words below. An administrator can connect a speech engine for this language in Connections."}
                </p>
              </div>
              <div className="record-actions">
                <button
                  className="primary"
                  disabled={
                    busy || !draft.evidence || !language?.available || !canEdit
                  }
                  onClick={transcribe}
                >
                  <FileText size={16} />
                  {busy ? "Preparing transcript…" : "Create AI transcript"}
                </button>
                <button
                  className="button"
                  disabled={busy || !canEdit}
                  onClick={() => setStep(2)}
                >
                  Type or paste transcript
                </button>
                <button
                  className="text-button"
                  disabled={busy}
                  onClick={() =>
                    act(async () => setStatus(await request("/api/speech")))
                  }
                >
                  <RefreshCw size={14} /> Check connection
                </button>
              </div>
            </>
          )}
          {step === 2 && (
            <>
              <p className="fine-print">
                Listen again and check names, places and wording. Your
                corrections are saved as a draft.
              </p>
              {draft.segments.length > 0 && (
                <div className="transcript-segments">
                  {draft.segments.map((s: any, i: number) => (
                    <div className="transcript-segment" key={i}>
                      <button
                        className="button"
                        disabled={!audioUrl}
                        onClick={() => {
                          if (player.current) {
                            player.current.currentTime = s.start;
                            player.current.play().catch(() => {});
                          }
                        }}
                      >
                        {time(s.start)} · Play
                      </button>
                      <label className="capture-label">
                        Clip {i + 1}
                        <textarea
                          rows={2}
                          value={s.text}
                          onChange={(e) => {
                            const segments = draft.segments.map(
                              (x: any, n: number) =>
                                n === i ? { ...x, text: e.target.value } : x,
                            );
                            setDraft({
                              ...draft,
                              segments,
                              text: segments.map((x: any) => x.text).join(" "),
                              reviewed: false,
                            });
                          }}
                        />
                      </label>
                    </div>
                  ))}
                </div>
              )}
              <label className="capture-label">
                Full transcript
                <textarea
                  aria-label="Full transcript"
                  className="extraction-output"
                  rows={6}
                  maxLength={60000}
                  value={draft.text}
                  placeholder="Enter the words spoken in the recording…"
                  onChange={(e) => editText(e.target.value)}
                />
              </label>
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={draft.reviewed}
                  onChange={(e) =>
                    setDraft({ ...draft, reviewed: e.target.checked })
                  }
                />{" "}
                I have checked this transcript against the recording
              </label>
              <button
                className="primary"
                disabled={
                  busy || !draft.text.trim() || !draft.reviewed || !canEdit
                }
                onClick={() =>
                  act(async () => {
                    await saveChain.current.catch(() => {});
                    await request("/api/capture-draft", draft);
                    addCaptured({
                      title:
                        draft.evidence?.name.replace(/\.[^.]+$/, "") ||
                        "New transcript",
                      body: draft.text,
                      evidence: draft.evidence,
                      language: draft.language,
                      channel: draft.evidence?.type.startsWith("video")
                        ? "Television"
                        : "Radio",
                      transcript: {
                        provider: draft.provider,
                        originalText: draft.originalText,
                        segments: draft.segments,
                        reviewed: true,
                      },
                      notes: "Transcript checked against the recording.",
                    });
                  })
                }
              >
                <Check size={16} /> Continue to story details
              </button>
            </>
          )}
        </>
      )}
      <div className="step-actions">
        <button
          className="button"
          disabled={step === 0 || busy || recording}
          onClick={() => setStep((s) => s - 1)}
        >
          Back
        </button>
        {step === 0 && draft.evidence && (
          <button
            className="button"
            disabled={busy || recording}
            onClick={() => setStep(1)}
          >
            Use saved recording <ArrowRight size={15} />
          </button>
        )}
        {draft.text && (
          <button
            className="text-button"
            disabled={busy || recording}
            onClick={() => {
              if (
                confirm(
                  "Clear this working draft? Saved stories and recordings will remain.",
                )
              )
                act(async () => {
                  await saveChain.current.catch(() => {});
                  await request("/api/capture-draft", { clear: true });
                  setDraft(empty);
                  setStep(0);
                  if (urlRef.current) URL.revokeObjectURL(urlRef.current);
                  setAudioUrl("");
                });
            }}
          >
            Clear draft
          </button>
        )}
      </div>
    </section>
  );
}
export function SpeechConnection({
  notice,
  admin,
}: {
  notice: (s: string) => void;
  admin: boolean;
}) {
  const [state, setState] = useState<any>(null),
    [busy, setBusy] = useState(false);
  async function load() {
    try {
      setState(await request("/api/speech"));
    } catch (e: any) {
      notice(e.message);
    }
  }
  useEffect(() => {
    load();
  }, []);
  return (
    <section className="panel integration-card">
      <div className="source-top">
        <h3>Namibian language engine</h3>
        <span className="badge neutral">{state?.status || "Checking…"}</span>
      </div>
      <p>Connect speech-to-text for your language studio.</p>
      {admin && (
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            setBusy(true);
            try {
              await request("/api/speech", {
                url: f.get("url"),
                token: f.get("token"),
              });
              notice("Speech connection tested");
            } catch (e: any) {
              notice(e.message);
            } finally {
              setBusy(false);
              load();
            }
          }}
        >
          <label className="capture-label">
            Speech service address
            <input
              aria-label="Speech service address"
              name="url"
              type="url"
              required
              key={state?.url}
              defaultValue={state?.url || "http://127.0.0.1:8876"}
            />
          </label>
          <label className="capture-label">
            Connection key
            <input
              aria-label="Connection key"
              name="token"
              type="password"
              autoComplete="new-password"
              placeholder="Leave blank to keep your saved key"
            />
          </label>
          <button className="primary" disabled={busy}>
            {busy ? "Checking…" : "Save & test connection"}
          </button>
        </form>
      )}
      <div className="keyword-tags">
        {state?.languages
          ?.filter((l: any) => l.available)
          .map((l: any) => (
            <span key={l.name}>
              {l.name}
              {l.experimental ? " · experimental" : ""}
            </span>
          ))}
      </div>
      {state?.error && <p className="connection-error">{state.error}</p>}
    </section>
  );
}
