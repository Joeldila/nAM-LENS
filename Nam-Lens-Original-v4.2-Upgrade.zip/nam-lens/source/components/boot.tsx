import React, { useEffect, useRef, useState } from "react";
import { ArrowRight, Menu, X } from "lucide-react";
import PublicGuide from "./public-guide";
const slides = [
  {
    title: "Many voices. One clear view.",
    text: "A media desk made for Namibia’s stories.",
  },
  {
    title: "From a voice to a story.",
    text: "Listen, capture and review in the language of the conversation.",
  },
  {
    title: "Understand. Then respond.",
    text: "Keep the evidence close. Give every story a meaningful next step.",
  },
];
export default function Boot({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<any>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [view, setView] = useState(
      location.pathname === "/guide"
        ? "guide"
        : location.pathname === "/register"
          ? "register"
          : location.pathname === "/login"
            ? "login"
            : "home",
    ),
    [slide, setSlide] = useState(0),
    [paused, setPaused] = useState(false),
    [interactionPaused, setInteractionPaused] = useState(false),
    [menu, setMenu] = useState(false),
    [pending, setPending] = useState(false);
  const formRef = useRef<HTMLFormElement>(null),
    touch = useRef(0);
  async function check() {
    try {
      const r = await fetch("/api/auth/status");
      if (!r.ok)
        throw Error(
          "Could not connect to Nam Lens. Keep the app’s start window open and try again.",
        );
      setState(await r.json());
      setError("");
    } catch (e: any) {
      setError(e.message);
    }
  }
  function go(next: string) {
    setView(next);
    setError("");
    setPending(false);
    setMenu(false);
    history.pushState({}, "", next === "home" ? "/" : "/" + next);
  }
  useEffect(() => {
    check();
    const listener = () => {
      setState(null);
      go("home");
      check();
    };
    const pop = () =>
      setView(
        location.pathname === "/guide"
          ? "guide"
          : location.pathname === "/register"
            ? "register"
            : location.pathname === "/login"
              ? "login"
              : "home",
      );
    window.addEventListener("nmo-auth-required", listener);
    window.addEventListener("popstate", pop);
    return () => {
      window.removeEventListener("nmo-auth-required", listener);
      window.removeEventListener("popstate", pop);
    };
  }, []);
  useEffect(() => {
    if (
      paused ||
      interactionPaused ||
      matchMedia("(prefers-reduced-motion: reduce)").matches
    )
      return;
    const t = setInterval(() => setSlide((s) => (s + 1) % slides.length), 6500);
    return () => clearInterval(t);
  }, [paused, interactionPaused]);
  useEffect(() => {
    if (["register", "login"].includes(view))
      formRef.current?.querySelector<HTMLInputElement>("input")?.focus();
  }, [view]);
  if (view === "guide") return <PublicGuide back={() => go("home")} />;
  if (state?.authenticated) return <>{children}</>;
  if (!state && !error)
    return (
      <div className="brand-loader" role="status">
        <img src="/favicon.svg" alt="" />
        <strong>Nam Lens</strong>
        <span>Opening your media desk…</span>
      </div>
    );
  return (
    <div className="landing">
      <header className="landing-header">
        <a
          className="landing-brand"
          href="/"
          onClick={(e) => {
            e.preventDefault();
            go("home");
          }}
        >
          <img src="/favicon.svg" alt="Nam Lens logo" />
          <strong>
            Nam <em>Lens</em>
          </strong>
        </a>
        <nav aria-label="Public navigation">
          <a
            href="/guide"
            onClick={(e) => {
              e.preventDefault();
              go("guide");
            }}
          >
            Explore Nam Lens
          </a>
          <button
            className="icon-button"
            aria-label="Open home menu"
            aria-expanded={menu}
            onClick={() => setMenu(!menu)}
          >
            {menu ? <X /> : <Menu />}
          </button>
          {menu && (
            <div className="landing-menu">
              <a
                href="/guide"
                onClick={(e) => {
                  e.preventDefault();
                  go("guide");
                }}
              >
                How to use Nam Lens
              </a>
              <button onClick={() => go("register")}>Create account</button>
              <button onClick={() => go("login")}>Log in</button>
            </div>
          )}
        </nav>
      </header>
      <main
        className={"landing-main " + (view !== "home" ? "auth-layout" : "")}
      >
        <div className="logo-scene" aria-hidden="true">
          <div className="orbit-ring ring-one" />
          <div className="orbit-ring ring-two" />
          {Array.from({ length: 8 }, (_, i) => (
            <i className={"logo-particle particle-" + i} key={i} />
          ))}
          <div className="assembled-logo">
            <img src="/favicon.svg" alt="" />
          </div>
          <div className="logo-shadow" />
          <span className="scene-caption">BUILT FOR NAMIBIA</span>
        </div>
        {view === "home" ? (
          <section
            className="landing-copy"
            aria-label="About Nam Lens"
            onMouseEnter={() => setInteractionPaused(true)}
            onMouseLeave={() => setInteractionPaused(false)}
            onFocus={() => setInteractionPaused(true)}
            onBlur={() => setInteractionPaused(false)}
            onTouchStart={(e) => (touch.current = e.touches[0].clientX)}
            onTouchEnd={(e) => {
              const distance = e.changedTouches[0].clientX - touch.current;
              if (Math.abs(distance) > 40)
                setSlide(
                  (s) =>
                    (s + (distance < 0 ? 1 : slides.length - 1)) %
                    slides.length,
                );
            }}
          >
            <div className="eyebrow">NAMIBIA, THROUGH A CLEARER LENS</div>
            <div className="flowing-slides">
              {slides.map((s, i) => (
                <div
                  className={"flow-slide " + (i === slide ? "current" : "")}
                  key={s.title}
                  aria-hidden={i !== slide}
                >
                  <h1>{s.title}</h1>
                  <p>{s.text}</p>
                </div>
              ))}
            </div>
            <div className="landing-actions">
              <button className="primary" onClick={() => go("register")}>
                Create account <ArrowRight size={18} />
              </button>
              <button className="button" onClick={() => go("login")}>
                Log in
              </button>
            </div>
            <div className="slide-controls">
              <div>
                {slides.map((s, i) => (
                  <button
                    key={s.title}
                    aria-label={"Show introduction " + (i + 1)}
                    aria-current={i === slide ? "true" : undefined}
                    className={i === slide ? "active" : ""}
                    onClick={() => setSlide(i)}
                  />
                ))}
              </div>
              <button
                className="text-button"
                onClick={() => setPaused(!paused)}
              >
                {paused ? "Play" : "Pause"} motion
              </button>
            </div>
            {state?.setup && (
              <p className="setup-hint">
                First visit? Create your owner account to get started.
              </p>
            )}
          </section>
        ) : (
          <section className="auth-card">
            <button className="text-button" onClick={() => go("home")}>
              ← Home
            </button>
            <div className="eyebrow">YOUR NAM LENS ACCOUNT</div>
            <h1>
              {pending
                ? "You’re on the list."
                : view === "register"
                  ? "Make room for your voice."
                  : "Welcome back."}
            </h1>
            {pending ? (
              <>
                <p>
                  Your account is saved. The workspace owner will approve your
                  access in Team & approvals.
                </p>
                <button className="primary" onClick={() => go("login")}>
                  Go to log in
                </button>
              </>
            ) : (
              <>
                <p>
                  {view === "register"
                    ? state?.setup
                      ? "Create the owner account for this local workspace."
                      : "Create an account to request access to this workspace."
                    : "Log in to your media desk."}
                </p>
                <form
                  ref={formRef}
                  onSubmit={async (e) => {
                    e.preventDefault();
                    setBusy(true);
                    setError("");
                    const fd = new FormData(e.currentTarget);
                    if (
                      view === "register" &&
                      fd.get("password") !== fd.get("confirm")
                    ) {
                      setError("Your passwords do not match.");
                      setBusy(false);
                      return;
                    }
                    try {
                      const r = await fetch(
                        "/api/auth/" +
                          (view === "register" ? "register" : "login"),
                        {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({
                            email: fd.get("email"),
                            password: fd.get("password"),
                            name: fd.get("name"),
                          }),
                        },
                      );
                      const j = await r.json();
                      if (!r.ok) throw Error(j.error);
                      if (j.pending) {
                        setPending(true);
                        e.currentTarget?.reset();
                      } else {
                        history.replaceState({}, "", "/");
                        setView("home");
                        await check();
                      }
                    } catch (e: any) {
                      setError(e.message);
                    } finally {
                      setBusy(false);
                    }
                  }}
                >
                  {view === "register" && (
                    <label>
                      Your name
                      <input
                        aria-label="Your name"
                        name="name"
                        autoComplete="name"
                        required
                        maxLength={100}
                      />
                    </label>
                  )}
                  <label>
                    Email address
                    <input
                      aria-label="Email address"
                      name="email"
                      type="email"
                      autoComplete="username"
                      required
                      maxLength={254}
                    />
                  </label>
                  <label>
                    Password
                    <input
                      aria-label="Password"
                      name="password"
                      type="password"
                      autoComplete={
                        view === "register"
                          ? "new-password"
                          : "current-password"
                      }
                      required
                      minLength={8}
                      maxLength={200}
                    />
                    {view === "register" && (
                      <small>At least 8 characters.</small>
                    )}
                  </label>
                  {view === "register" && (
                    <label>
                      Confirm password
                      <input
                        aria-label="Confirm password"
                        name="confirm"
                        type="password"
                        required
                        minLength={8}
                        maxLength={200}
                        autoComplete="new-password"
                      />
                    </label>
                  )}
                  <button className="primary" disabled={busy}>
                    {busy
                      ? "Please wait…"
                      : view === "register"
                        ? "Create account"
                        : "Log in"}
                    <ArrowRight size={17} />
                  </button>
                </form>
                <button
                  className="text-button auth-switch"
                  onClick={() => go(view === "register" ? "login" : "register")}
                >
                  {view === "register"
                    ? "Already have an account? Log in"
                    : "New to Nam Lens? Create account"}
                </button>
              </>
            )}
            {error && (
              <p className="connection-error" role="alert">
                {error}
              </p>
            )}
          </section>
        )}
        {error && view === "home" && (
          <div className="connection-error" role="alert">
            {error}
            <button className="button" onClick={check}>
              Try again
            </button>
          </div>
        )}
      </main>
      <footer className="landing-footer">
        <span>Many voices. One clear view.</span>
        <a
          href="/guide"
          onClick={(e) => {
            e.preventDefault();
            go("guide");
          }}
        >
          A guide for everyone →
        </a>
      </footer>
    </div>
  );
}
