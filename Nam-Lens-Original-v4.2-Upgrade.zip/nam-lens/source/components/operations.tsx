import StepFields from "@/components/step-fields";
import React, { useEffect, useState } from "react";
import {
  Radio,
  ShieldCheck,
  Activity,
  Plus,
  RefreshCw,
  Check,
  Globe2,
  Download,
} from "lucide-react";
import { languages, regions } from "@/lib/analysis";
const stamp = (d: string) =>
  d
    ? new Date(d).toLocaleString("en-GB", { timeZone: "Africa/Windhoek" })
    : "No run yet";
export default function Operations({
  page,
  session,
  notice,
}: {
  page: string;
  session: any;
  notice: (s: string) => void;
}) {
  const [state, setState] = useState<any>(null),
    [draft, setDraft] = useState<any>(null),
    [busy, setBusy] = useState(false),
    [language, setLanguage] = useState("English");
  const admin = session?.role === "Admin",
    review = ["Admin", "Reviewer"].includes(session?.role);
  const endpoint =
    page === "Broadcast desk"
      ? "/api/broadcast"
      : page === "Language quality"
        ? "/api/languages"
        : "/api/readiness";
  async function request(url: string, d?: any) {
    const r = await fetch(
      url,
      d
        ? {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(d),
          }
        : {},
    );
    const j = await r.json();
    if (!r.ok) throw Error(j.error);
    return j;
  }
  async function load() {
    try {
      setState(await request(endpoint));
    } catch (e: any) {
      notice(e.message);
    }
  }
  useEffect(() => {
    setState(null);
    load();
    const t = setInterval(load, 20000);
    return () => clearInterval(t);
  }, [page]);
  async function act(f: () => Promise<any>) {
    setBusy(true);
    try {
      await f();
      await load();
    } catch (e: any) {
      notice(e.message);
    } finally {
      setBusy(false);
    }
  }
  if (
    (page === "Service status" && !admin) ||
    (page === "Language quality" && !review)
  )
    return (
      <section className="panel empty">
        <ShieldCheck />
        <h3>Restricted workspace tools</h3>
        <p>Ask a workspace administrator for access.</p>
      </section>
    );
  const fresh = {
    name: "",
    url: "",
    channel: "Radio",
    language: "English",
    region: "National",
    seconds: 120,
    retentionDays: 3,
    enabled: false,
    transcribe: false,
    programme: "",
    presenter: "",
  };
  return (
    <div className="operations">
      {page === "Broadcast desk" && (
        <>
          <div className="insight-banner">
            <Radio />
            <div>
              <h3>From live broadcast to reviewed evidence.</h3>
              <p>
                Capture direct HTTPS streams and HLS playlists in short clips.
                Recordings, transcripts and source details stay linked to the
                stories. Television captures retain video when the stream
                supports it.
              </p>
            </div>
          </div>
          <div className="section-toolbar">
            <span>
              {state?.running || 0} active captures · Maximum 2 streams ·
              Recording engine {state?.ffmpeg ? "available" : "needs setup"}
            </span>
            {admin && (
              <div className="record-actions">
                <button
                  className="button"
                  disabled={busy}
                  onClick={() =>
                    act(() => request(endpoint, { action: "run" }))
                  }
                >
                  <RefreshCw size={16} /> Check streams now
                </button>
                <button
                  className="primary"
                  onClick={() => setDraft({ ...fresh })}
                >
                  <Plus size={16} /> Add stream
                </button>
              </div>
            )}
          </div>
          {draft && (
            <section className="panel capture-panel">
              <h3>{draft.id ? "Edit stream" : "New broadcast stream"}</h3>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  act(async () => {
                    await request(endpoint, draft);
                    setDraft(null);
                    notice("Stream configuration saved");
                  });
                }}
              >
                <StepFields
                  names={["The basics", "More details", "Review & finish"]}
                  size={6}
                >
                  <label>
                    Station name
                    <input
                      aria-label="Station name"
                      required
                      value={draft.name}
                      onChange={(e) =>
                        setDraft({ ...draft, name: e.target.value })
                      }
                    />
                  </label>
                  <label>
                    Channel
                    <select
                      aria-label="Channel"
                      value={draft.channel}
                      onChange={(e) =>
                        setDraft({ ...draft, channel: e.target.value })
                      }
                    >
                      <option>Radio</option>
                      <option>Television</option>
                    </select>
                  </label>
                  <label className="full">
                    Direct HTTPS stream or HLS playlist URL
                    <input
                      aria-label="Direct HTTPS stream or HLS playlist URL"
                      required
                      type="url"
                      value={draft.url}
                      onChange={(e) =>
                        setDraft({ ...draft, url: e.target.value })
                      }
                      placeholder="https://station.example/live.m3u8"
                    />
                  </label>
                  <label>
                    Language
                    <select
                      aria-label="Language"
                      value={draft.language}
                      onChange={(e) =>
                        setDraft({ ...draft, language: e.target.value })
                      }
                    >
                      {languages.map((x) => (
                        <option key={x}>{x}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Region
                    <select
                      aria-label="Region"
                      value={draft.region}
                      onChange={(e) =>
                        setDraft({ ...draft, region: e.target.value })
                      }
                    >
                      {regions.map((x) => (
                        <option key={x}>{x}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Programme
                    <input
                      aria-label="Programme"
                      value={draft.programme}
                      onChange={(e) =>
                        setDraft({ ...draft, programme: e.target.value })
                      }
                    />
                  </label>
                  <label>
                    Presenter
                    <input
                      aria-label="Presenter"
                      value={draft.presenter}
                      onChange={(e) =>
                        setDraft({ ...draft, presenter: e.target.value })
                      }
                    />
                  </label>
                  <label>
                    Clip length
                    <select
                      aria-label="Clip length"
                      value={draft.seconds}
                      onChange={(e) =>
                        setDraft({ ...draft, seconds: Number(e.target.value) })
                      }
                    >
                      {[30, 60, 120, 300, 600].map((x) => (
                        <option key={x} value={x}>
                          {x} seconds
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Recording retention (days)
                    <input
                      aria-label="Recording retention (days)"
                      type="number"
                      min={1}
                      max={30}
                      value={draft.retentionDays}
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          retentionDays: Number(e.target.value),
                        })
                      }
                    />
                  </label>
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={draft.enabled}
                      onChange={(e) =>
                        setDraft({ ...draft, enabled: e.target.checked })
                      }
                    />{" "}
                    Keep capturing while the server runs
                  </label>
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={draft.transcribe}
                      onChange={(e) =>
                        setDraft({ ...draft, transcribe: e.target.checked })
                      }
                    />{" "}
                    Queue transcription after each clip
                  </label>
                </StepFields>
                <p className="fine-print">
                  Speech connections support English, Afrikaans and German.
                  Other languages require a human transcript. Recording
                  retention deletes expired original clips; story records
                  remain. A storage cap pauses collection before the disk fills.
                </p>
                <div className="record-actions">
                  <button className="primary" disabled={busy}>
                    Save stream
                  </button>
                  <button
                    className="button"
                    type="button"
                    onClick={() => setDraft(null)}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </section>
          )}
          <div className="two-col">
            {state?.streams?.map((s: any) => (
              <section className="panel capture-panel" key={s.id}>
                <div className="source-top">
                  <h3>{s.name}</h3>
                  <span
                    className={
                      "badge " +
                      (s.health === "Recording" ? "positive" : "neutral")
                    }
                  >
                    {s.health}
                  </span>
                </div>
                <p>
                  {s.channel} · {s.language} · {s.seconds}s clips ·{" "}
                  {s.retentionDays} day retention
                </p>
                <p className="fine-print">
                  Last capture: {stamp(s.lastCapture)}
                </p>
                {s.lastError && (
                  <p className="connection-error">{s.lastError}</p>
                )}
                {admin && (
                  <div className="record-actions">
                    <button
                      className="button"
                      onClick={() => setDraft({ ...fresh, ...s })}
                    >
                      Edit stream
                    </button>
                    <button
                      className="button"
                      disabled={busy}
                      onClick={() =>
                        act(() =>
                          request(endpoint, { ...s, enabled: !s.enabled }),
                        )
                      }
                    >
                      {s.enabled ? "Pause" : "Start capture"}
                    </button>
                    {!s.enabled && (
                      <button
                        className="danger-button"
                        disabled={busy}
                        onClick={() =>
                          act(() =>
                            request(endpoint, { id: s.id, action: "delete" }),
                          )
                        }
                      >
                        Remove
                      </button>
                    )}
                  </div>
                )}
              </section>
            ))}
          </div>
          {state && !state.streams.length && (
            <section className="panel empty">
              <Radio size={32} />
              <h3>Your national listening desk</h3>
              <p>
                Add a station’s working stream URL to start. No stations are
                recorded without a configured source.
              </p>
            </section>
          )}
          <section className="panel section-gap">
            <div className="panel-heading">
              <h3>Transcription queue</h3>
            </div>
            <div className="table-scroll">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Queued (CAT)</th>
                    <th>Language</th>
                    <th>Status</th>
                    <th>Detail</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {state?.queue?.map((q: any) => (
                    <tr key={q.id}>
                      <td>{stamp(q.date)}</td>
                      <td>{q.language}</td>
                      <td>{q.status}</td>
                      <td>{q.error || "Recording linked to its story"}</td>
                      <td>
                        {["Admin", "Reviewer", "Analyst"].includes(
                          session?.role,
                        ) &&
                          ["Retry", "Needs attention"].includes(q.status) && (
                            <button
                              className="button"
                              disabled={busy}
                              onClick={() =>
                                act(() =>
                                  request("/api/transcription/retry", {
                                    id: q.id,
                                  }),
                                )
                              }
                            >
                              Retry
                            </button>
                          )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
      {page === "Language quality" && (
        <>
          <div className="insight-banner">
            <Globe2 />
            <div>
              <h3>Measure accuracy before trusting a model.</h3>
              <p>
                Import examples independently labelled by fluent speakers, then
                compare the connected model with those labels. Every language
                keeps its own measured results. A benchmark does not replace
                analyst review.
              </p>
            </div>
          </div>
          <section className="panel capture-panel">
            <h3>Reference examples</h3>
            <p>Add examples checked by a fluent speaker.</p>
            <label className="button">
              Import saved examples
              <input
                className="hidden-file"
                type="file"
                accept=".json"
                disabled={busy}
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f)
                    act(async () => {
                      if (f.size > 500000)
                        throw Error("Choose an examples file below 500 KB");
                      await request(endpoint, {
                        items: JSON.parse(await f.text()),
                      });
                      notice("Reference examples imported");
                    });
                  e.target.value = "";
                }}
              />
            </label>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = e.currentTarget,
                  fd = new FormData(form);
                act(async () => {
                  await request(endpoint, {
                    items: [
                      {
                        text: fd.get("text"),
                        language: fd.get("language"),
                        sentiment: fd.get("sentiment"),
                      },
                    ],
                  });
                  form.reset();
                  notice("Reference example saved");
                });
              }}
            >
              <label className="capture-label">
                Language
                <select
                  aria-label="Language"
                  name="language"
                  defaultValue={language}
                >
                  {languages.map((x) => (
                    <option key={x}>{x}</option>
                  ))}
                </select>
              </label>
              <label className="capture-label">
                Example text
                <textarea
                  aria-label="Example text"
                  name="text"
                  className="extraction-output"
                  rows={3}
                  required
                  maxLength={5000}
                />
              </label>
              <label className="capture-label">
                Tone checked by a fluent speaker
                <select
                  aria-label="Tone checked by a fluent speaker"
                  name="sentiment"
                >
                  <option>Positive</option>
                  <option>Negative</option>
                  <option>Neutral</option>
                </select>
              </label>
              <button className="button" disabled={busy}>
                Save example
              </button>
            </form>
            <div className="record-actions">
              <label>
                Language to check
                <select
                  aria-label="Language to check"
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                >
                  {languages.map((x) => (
                    <option key={x}>{x}</option>
                  ))}
                </select>
              </label>
              <button
                className="primary"
                disabled={busy}
                onClick={() =>
                  act(async () => {
                    await request(endpoint, { action: "evaluate", language });
                    notice("Language results saved");
                  })
                }
              >
                {busy ? "Checking…" : "Check connected model"}
              </button>
            </div>
            <p className="fine-print">
              {state?.benchmarks?.length || 0} labelled examples saved. Each
              evaluation uses up to 30 examples and may incur provider usage.
              The custom language service is configured by your host
              administrator.
            </p>
          </section>
          <div className="two-col">
            {state?.results?.map((q: any) => (
              <section className="panel capture-panel" key={q.id}>
                <div className="source-top">
                  <h3>{q.language}</h3>
                  <span className="badge neutral">
                    {q.accuracy === null
                      ? "No result"
                      : Math.round(q.accuracy * 100) + "% agreement"}
                  </span>
                </div>
                <p>{q.status}</p>
                <p>
                  {q.evaluated} evaluated / {q.count} examples ·{" "}
                  {q.classes?.length} reference classes
                </p>
                <p className="fine-print">{stamp(q.date)}</p>
                {q.errors?.length > 0 && (
                  <p className="connection-error">{q.errors[0].error}</p>
                )}
                <details>
                  <summary>Expected tone compared with suggested tone</summary>
                  <div className="table-scroll">
                    <table className="data-table">
                      <thead>
                        <tr>
                          <th>Expected tone</th>
                          <th>Suggested tone</th>
                          <th>Examples</th>
                        </tr>
                      </thead>
                      <tbody>
                        {Object.entries(q.confusion || {}).flatMap(
                          ([expected, values]: any) =>
                            Object.entries(values).map(
                              ([suggested, total]: any) => (
                                <tr key={expected + suggested}>
                                  <td>{expected}</td>
                                  <td>{suggested}</td>
                                  <td>{total}</td>
                                </tr>
                              ),
                            ),
                        )}
                      </tbody>
                    </table>
                  </div>
                </details>
              </section>
            ))}
          </div>
        </>
      )}
      {page === "Service status" && (
        <>
          <div className="insight-banner">
            <Activity />
            <div>
              <h3>Know what is connected and working.</h3>
              <p>
                This screen reports actual configuration and recorded results. A
                saved connection key alone does not prove successful collection
                or language accuracy.
              </p>
            </div>
          </div>
          <div className="two-col">
            <section className="panel capture-panel">
              <h3>Workspace</h3>
              <dl>
                <dt>Version</dt>
                <dd>{state?.version}</dd>
                <dt>Run mode</dt>
                <dd>{state?.mode}</dd>
                <dt>Sign-in</dt>
                <dd>{state?.signIn ? "Enabled" : "Local direct access"}</dd>
                <dt>Broadcast engine</dt>
                <dd>
                  {state?.ffmpeg ? "Available" : "Recording engine needs setup"}
                </dd>
                <dt>Transcription worker</dt>
                <dd>{state?.speech?.status}</dd>
                <dt>Analysis queue</dt>
                <dd>
                  {state?.analysisQueue?.length || 0} pending / failed tasks
                </dd>
                <dt>Recording queue</dt>
                <dd>{state?.queued || 0} pending / failed tasks</dd>
                <dt>External crisis notifications</dt>
                <dd>
                  {state?.alerts?.configured
                    ? state?.alerts?.emailConfigured
                      ? "Email connected"
                      : "Delivery service connected"
                    : "No delivery connection"}
                </dd>
              </dl>
              <p className="fine-print">
                External access tests, real station URLs and language benchmarks
                still need to pass for your selected sources.
              </p>
            </section>
            <section className="panel capture-panel">
              <h3>Automatic backups</h3>
              <p>
                Daily snapshots include the database, encryption key and
                original attachments. Three local snapshots are retained. Keep
                an additional copy away from the server.
              </p>
              <p>
                Last result:{" "}
                {state?.backup?.status || "Waiting for first snapshot"} ·{" "}
                {stamp(state?.backup?.date)}
              </p>
              {state?.backup?.error && (
                <p className="connection-error">{state.backup.error}</p>
              )}
              <button
                className="primary"
                disabled={busy}
                onClick={() =>
                  act(async () => {
                    await request("/api/backup/automatic", {});
                    notice("Snapshot saved");
                  })
                }
              >
                <Check size={16} /> Create snapshot now
              </button>
            </section>
          </div>
          <section className="panel section-gap">
            <div className="panel-heading">
              <h3>Feed connections</h3>
              <button className="button" disabled={busy} onClick={load}>
                <RefreshCw size={14} /> Refresh status
              </button>
            </div>
            <div className="table-scroll">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Source</th>
                    <th>Enabled</th>
                    <th>Health</th>
                    <th>Last successful import</th>
                    <th>Error</th>
                  </tr>
                </thead>
                <tbody>
                  {state?.feeds?.map((x: any) => (
                    <tr key={x.name}>
                      <td>{x.name}</td>
                      <td>{x.enabled ? "Yes" : "No"}</td>
                      <td>{x.health}</td>
                      <td>{stamp(x.lastSync)}</td>
                      <td>{x.error || "None recorded"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
          <section className="panel section-gap">
            <div className="panel-heading">
              <h3>Provider activation</h3>
            </div>
            {state?.integrations?.map((x: any) => (
              <div className="readiness-row" key={x.id}>
                <strong>{x.name}</strong>
                <span>
                  {x.enabled ? "Enabled" : "Disabled"} ·{" "}
                  {x.configured ? "Configured" : "Credentials required"}
                </span>
                <span>{x.health}</span>
              </div>
            ))}
          </section>
        </>
      )}
    </div>
  );
}
